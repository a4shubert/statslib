from gmt.fom.gas.shared.utils.common import logger


def send_mail(from_, to_, subject, text, server):
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from_address = from_
    eml = MIMEMultipart()
    eml['From'] = from_address
    eml['To'] = to_
    eml['Subject'] = subject
    eml.attach(MIMEText(text, 'plain'))
    server = smtplib.SMTP(server)
    server.sendmail(from_address, to_, eml.as_string())
    server.quit()
    logger.debug('Sent email')