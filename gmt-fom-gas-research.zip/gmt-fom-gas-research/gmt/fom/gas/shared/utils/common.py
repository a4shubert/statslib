from collections import namedtuple
from datetime import datetime
import functools as _functools
from functools import wraps
import inspect
import logging
import operator as _operator
from pyad.adquery import ADQuery
from pyad.aduser import ADUser

import IPython as _ipython

logger = logging.getLogger(__file__)

flatten_lst = lambda my_lst: _functools.reduce(_operator.iconcat, my_lst, [])


def print_list_columnwise(ths_list,
                          ths_title=None,
                          sort=False,
                          *args,
                          **kwargs):
    if ths_title is not None:
        print("\n{}".format(ths_title))
    print("-" * 100)
    if len(ths_list) > 50:
        my_displaywidth = 100
    else:
        my_displaywidth = 40

    ths_list = [str(val) for val in ths_list]
    if sort:
        ths_list = sorted(ths_list)
    print(
        _ipython.utils.text.columnize(
            ths_list,
            displaywidth=kwargs.get('displaywidth', my_displaywidth),
            spread=kwargs.get('spread', False),
            row_first=kwargs.get('row_first', False),
            separator=kwargs.get('separator', '| '),
        ))


def pa(ths_obj,
       public_only=False,
       return_attributes=False,
       silent=False,
       methods_only=False,
       members_only=False,
       *args,
       **kwargs):
    ths_attributes_list = dir(ths_obj)
    if methods_only:
        ths_attributes_list = [
            attr for attr in ths_attributes_list
            if inspect.ismethod(getattr(ths_obj, attr))
        ]

    if members_only:
        ths_attributes_list = [
            attr for attr in ths_attributes_list
            if not inspect.ismethod(getattr(ths_obj, attr))
        ]

    ths_dbl_uscore_attributes = sorted([
        attribute for attribute in ths_attributes_list
        if attribute.startswith('_') and attribute[1] == '_'
    ])
    ths_uscore_attributes = [
        attribute for attribute in ths_attributes_list
        if attribute.startswith('_')
    ]
    ths_uscore_attributes = set(ths_uscore_attributes).difference(
        set(ths_dbl_uscore_attributes))
    ths_uscore_attributes = sorted(list(ths_uscore_attributes))

    ths_attributes = set(ths_attributes_list).difference(
        set(ths_uscore_attributes).union(set(ths_dbl_uscore_attributes)))
    ths_attributes = sorted(list(ths_attributes))

    if not silent:
        if public_only:
            print_list_columnwise(sorted(ths_attributes), "Public attributes",
                                  *args, **kwargs)
        else:
            print_list_columnwise(sorted(ths_attributes), "Public attributes",
                                  *args, **kwargs)
            print_list_columnwise(sorted(ths_uscore_attributes),
                                  "Private attributes:", *args, **kwargs)
            print_list_columnwise(sorted(ths_dbl_uscore_attributes),
                                  "Class specific attributes:", *args,
                                  **kwargs)

    if return_attributes:
        return {
            'public_atr': ths_attributes,
            'private_atr': ths_uscore_attributes,
            'class_atr': ths_dbl_uscore_attributes
        }


def to_namedtuple(d, recursive=True):
    if isinstance(d, dict):
        d = d.copy()
        if recursive:
            for k, v in d.items():
                d[k] = to_namedtuple(v, recursive)
        d = namedtuple('_', d.keys())(**d)

    return d


def save_to_json(file_path=None, data=None):
    import json
    with open(file_path, 'w') as f:
        json.dump(data, f)


def read_from_json(file_path=None):
    import json
    with open(file_path, 'r') as f:
        return json.load(f)


def get_ad_user_email(username):
    query = ADQuery()
    query.execute_query(where_clause=f"sAMAccountName = '{username}'",
                        base_dn=None,
                        options={},
                        type="GC")
    dist_name = query.get_single_result()['distinguishedName']
    user = ADUser(distinguished_name=dist_name)
    return user.mail.lower()


def report_run_time(long_format=True, f_name=None):
    def return_time_delta_list(start, finish):
        """
        Returns the time delta list between t2 and start
        :param start:
        :param finish:
        :return:
        """
        import datetime
        # we want finish be greater than start: finish>start
        if start > finish:
            start = finish
            finish = start
        else:
            start = start
            finish = finish
        ths_time_delta = finish - start
        ths_total_seconds = ths_time_delta.total_seconds()

        ths_hours = divmod(ths_total_seconds, 3600)[0]
        ths_minutes = divmod(ths_total_seconds - ths_hours * 3600, 60)[0]
        ths_seconds = ths_total_seconds - ths_hours * 3600 - ths_minutes * 60

        new_t2 = start + datetime.timedelta(
            hours=ths_hours, minutes=ths_minutes, seconds=ths_seconds)
        status = new_t2 == finish

        if not status:
            raise ValueError(
                "The calculated value of time difference is wrong! Check return_time_delta_list function!"
            )
        else:
            return [ths_hours, ths_minutes, ths_seconds, status]

    def next_decorator(a_func):

        @wraps(a_func)
        def decorated(*args, **kwargs):
            started = datetime.now()
            result = a_func(*args, **kwargs)
            finished = datetime.now()
            time_delta = return_time_delta_list(started, finished)
            if long_format:
                logger.info(
                    'Function {} took {:.2f} hours {:.2f} minutes and {:.0f} seconds.'
                        .format(a_func.__name__ if f_name is None else f_name,
                                time_delta[0], time_delta[1], time_delta[2]))
            else:
                logger.info(
                    'Function {} took {:.2f} minutes and {:.0f} seconds.'.
                        format(a_func.__name__ if f_name is None else f_name,
                               time_delta[1], time_delta[2]))
            return result

        return decorated

    return next_decorator


def set_check(left, right):
    left_diff_right = set(left).difference(right)
    right_diff_left = set(right).difference(left)
    return left_diff_right, right_diff_left


def consecutive_pairs_of_list_elements(l: list):
    '''
    Given list L=[1,2,3] produces generator of
    (1,2) (2,3)
    '''
    return zip(l[:-1], l[1:])


