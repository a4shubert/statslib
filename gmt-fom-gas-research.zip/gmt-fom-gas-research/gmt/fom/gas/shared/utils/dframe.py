import pandas as pd
from IPython import display
import matplotlib.pyplot as plt
import math

def plot_to_grid(df, curves, title, legend_on_a_side=False):
    L = 3
    K = math.ceil(len(curves) / L)
    i = j = 0
    fig, axs = plt.subplots(K, L, figsize=(15, 15))
    for curve in curves:
        df[curve].plot(ax=axs[i, j])
        axs[i, j].legend([curve])
        j += 1
        if j % L == 0:
            i += 1
            j = 0
    plt.suptitle(title)
    if legend_on_a_side:
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


def df_see_null_na_values(df):
    from IPython.display import display
    display(df[df.isnull().any(axis=1)])
    display(df[df.isna().any(axis=1)])


def to_pd_todatetime(df, col, day_only=False, **kwargs):
    if isinstance(col, list):
        cols = col
        for col in cols:
            df[col] = df[col].apply(lambda t: pd.to_datetime(t, **kwargs))
    else:
        df[col] = df[col].apply(lambda t: pd.to_datetime(t, **kwargs))

    if day_only:
        df[col] = df[col].apply(lambda t: t.date())
    return df


def ddff(df):
    if isinstance(df, pd.Series):
        df = df.to_frame()

    pd.set_option('display.max_rows', pd.DataFrame(df).shape[0])
    pd.set_option('display.max_columns', pd.DataFrame(df).shape[1])
    pd.set_option('display.max_colwidth', 1000)
    display.display(pd.DataFrame(df))

    pd.reset_option('display.max_rows')
    pd.reset_option('display.max_columns')
    pd.reset_option('display.max_colwidth')
