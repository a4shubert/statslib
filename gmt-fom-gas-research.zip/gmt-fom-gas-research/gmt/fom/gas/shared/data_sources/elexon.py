import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__file__)
logger.setLevel(logging.DEBUG)

## Plotting
import seaborn as sns
import matplotlib.pyplot as plt

## Custom 
import ElexonDataPortal.API as edp_API
from ElexonDataPortal import cleaner, plotter

API_key = 'kbvdr9mh0hpuxs2'

edp_wrapper = edp_API.Wrapper(API_key)

stream = 'FUELHH'

if __name__ == '__main__':

    query_args = {
        'start_date': '2010-01-01',
        'end_date': '2021-12-31',
    }

    df_generation = edp_wrapper.query_orchestrator(stream, query_args)

    df_generation.to_csv(r'C:\git\elexon_data_portal_download.csv', index=False)