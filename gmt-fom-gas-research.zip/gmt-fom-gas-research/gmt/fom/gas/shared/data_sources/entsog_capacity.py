import datetime
import logging

import pandas as pd
from datetime import timedelta
from gmt.fom.gas.shared.data_sources.mongo import GasMongo

logger = logging.getLogger(__file__)

class MongoAdapter:
    GAS_MODELS_DB = 'GasModels'
    ENTSOG_CAPACITY_COLLECTION = 'entsog_capacity'

    def __init__(self):
        self.mongo = GasMongo()
        self.mongo.choose_db(MongoAdapter.GAS_MODELS_DB)
        print('hi chris')

    def persist(self, df, t):
        self.mongo.choose_collection(MongoAdapter.ENTSOG_CAPACITY_COLLECTION)
        self.mongo.collection.delete_many(
            {EntsogCapacityDataScrapper.RUN_DAY: pd.to_datetime(t)})
        if df is not None and df.shape[0] > 0:
            self.mongo.pandas_to_mongo(df)
        else:
            logger.info(f'Empty dataFrame for t={t}')

    def load_entsog_capacity(self, t_range, query=None):
        self.mongo.choose_collection(MongoAdapter.ENTSOG_CAPACITY_COLLECTION)
        if query is None:
            res = pd.concat([
                self.mongo.select({EntsogCapacityDataScrapper.RUN_DAY: pd.to_datetime(t)})
                for t in t_range],
                axis=0)
        else:
            res = self.mongo.select(query)
        return res

    @property
    def cached_t_range(self):
        self.mongo.choose_collection(MongoAdapter.ENTSOG_CAPACITY_COLLECTION)
        t_range = self.mongo.collection.distinct(EntsogCapacityDataScrapper.RUN_DAY)
        t_range = [t.date() for t in t_range]
        return t_range

    def load_cache(self, t_range, query=None):
        self.mongo.choose_collection(MongoAdapter.ENTSOG_CAPACITY_COLLECTION)
        if query is None:
            res = pd.concat([
                self.mongo.select({EntsogCapacityDataScrapper.RUN_DAY: pd.to_datetime(t)})
                for t in t_range],
                axis=0)
        else:
            res = self.mongo.select(query)
        return res



class EntsogCapacityDataScrapper:
    RUN_DAY = 'run_day'

    def __init__(self):
        # ----------------Dates used in API URL ----------------------------------------------------------------------
        self.df_decomp = None
        self.today = datetime.date.today()
        self.run_day = self.today
        self.yesterday = self.today - datetime.timedelta(days=1)
        self.tomorrow = self.today + datetime.timedelta(days=665)

        self.fromDate = self.yesterday.strftime('%Y-%m-%d')
        self.toDate = self.tomorrow.strftime('%Y-%m-%d')
        self.data_adaptor = MongoAdapter()

    def query_data(self):
        self.url = (
                "https://transparency.entsog.eu/api/v1/operationalData.csv?&" +
                "delimiter=comma&" +
                "indicator=" +
                "Firm%20Technical," +
                "Firm%20Booked," +
                "Firm%20Available," +
                "Interruptible%20Total," +
                "Interruptible%20Booked" +
                "Interruptible%20Available" +
                "&periodType=day&timezone=CET&limit=-1&dataset=1"
                + "&from=" +
                self.fromDate +
                "&to=" +
                self.toDate
        )
        self.df = pd.read_csv(self.url)

    def filter_columns(self):
        columns = ['id', 'indicator', 'periodType', 'periodFrom', 'periodTo',
                   'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey', 'pointLabel',
                   'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
                   'value']
        self.df = self.df[columns]

    def convert_columns(self):
        df = self.df
        df[['periodFrom', 'periodTo', 'lastUpdateDateTime']] = df[
            ['periodFrom', 'periodTo', 'lastUpdateDateTime']].apply(pd.to_datetime)
        df[['unit']] = 'GWh/d'
        df[['value']] = df[['value']] * 1.0e-7
        df.reset_index(drop=True, inplace=True)
        df = df.sort_values(['tsoItemIdentifier', 'directionKey']).copy()
        self.df = df

    def country_connection_id(self):
        # ====================================
        # Creates a list of all the operator keys from the Full Data so that we search for the to and from countries below
        TotalOperatorKeys = self.df['operatorKey'].unique()
        self.TotalOperatorKeys = TotalOperatorKeys.tolist()

        # ==================================
        # Looks up all the Countries each connection if flow from.
        CountryconnectionID = pd.DataFrame()

        for url in TotalOperatorKeys:
            try:
                url = "https://transparency.entsog.eu/api/v1/Interconnections.csv?&fromOperatorKey=" + url
                df1 = pd.read_csv(url)
                CountryconnectionID = CountryconnectionID.append(df1)
            except:
                pass

        Columns = ['fromSystemLabel', 'fromCountryKey', 'fromCountryLabel',
                   'fromOperatorKey', 'fromTsoItemIdentifier',
                   'toSystemLabel', 'toCountryKey', 'toCountryLabel']

        CountryconnectionID = CountryconnectionID[Columns]

        CountryconnectionID.rename(columns={'fromTsoItemIdentifier': 'tsoItemIdentifier',
                                            'fromOperatorKey': 'operatorKey'}, inplace=True)
        self.CountryconnectionID = CountryconnectionID

    def from_country_data(self):
        FromCountryData = pd.merge(self.df, self.CountryconnectionID, on=['operatorKey', 'tsoItemIdentifier'],
                                   how='outer')
        ToCountryData = FromCountryData[FromCountryData['fromCountryLabel'].isnull()]

        FromCountryData = FromCountryData.dropna()
        ToCountryData = ToCountryData[ToCountryData['tsoEicCode'].notna()]
        columns = ['id', 'indicator', 'periodType', 'periodFrom', 'periodTo',
                   'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey', 'pointLabel',
                   'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
                   'value']

        self.ToCountryData = ToCountryData[columns]

        FromCountryData.rename(columns={'fromCountryKey': 'toCountryCode',
                                        'fromSystemLabel': 'toSystem',
                                        'fromCountryLabel': 'toCountry',
                                        'toCountryLabel': 'fromCountry',
                                        'toSystemLabel': 'fromSystem',
                                        'toCountryKey': 'fromCountryCode'}, inplace=True)
        self.FromCountryData = FromCountryData

    def other_countries_connection_id(self):
        # ==========================================
        # Looks up all the connections that countries are flowing to

        Other_CountryconnectionID = pd.DataFrame()

        for url in self.TotalOperatorKeys:
            try:
                url = "https://transparency.entsog.eu/api/v1/Interconnections.csv?&toOperatorKey=" + url
                df1 = pd.read_csv(url)

                Other_CountryconnectionID = Other_CountryconnectionID.append(df1)
            except:
                pass

        columns = ['fromSystemLabel', 'fromCountryKey', 'fromCountryLabel',
                   'toSystemLabel', 'toCountryKey', 'toCountryLabel', 'toOperatorKey',
                   'toTsoItemIdentifier']

        Other_CountryconnectionID = Other_CountryconnectionID[columns]

        # Renames the columns so that the different dataframes can me joined together
        Other_CountryconnectionID.rename(columns={'toTsoItemIdentifier': 'tsoItemIdentifier',
                                                  'toOperatorKey': 'operatorKey'}, inplace=True)

        # ==========================================
        # Joins the dataframes on the columns tsoItemIdentifer and operatorKey
        OtherCountryData = pd.merge(self.ToCountryData, Other_CountryconnectionID,
                                    on=['operatorKey', 'tsoItemIdentifier'],
                                    how='outer')
        # Keeps only the rows with data in the tsoEicCode column
        OtherCountryData = OtherCountryData[OtherCountryData['tsoEicCode'].notna()]
        OtherCountryData = OtherCountryData[OtherCountryData['pointLabel'].notna()]
        OtherCountryData = OtherCountryData.dropna()

        OtherCountryData.rename(columns={'fromSystemLabel': 'fromSystem',
                                         'fromCountryKey': 'fromCountryCode',
                                         'fromCountryLabel': 'fromCountry',
                                         'toSystemLabel': 'toSystem',
                                         'toCountryKey': 'toCountryCode',
                                         'toCountryLabel': 'toCountry'}, inplace=True)
        self.OtherCountryData = OtherCountryData

    def combine(self):
        # Combines the two complete dataframes together
        Final = self.OtherCountryData.append([self.FromCountryData])
        # Removes the foregin letters
        Final['pointLabel'] = Final['pointLabel'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode(
            'utf-8')
        Final['operatorLabel'] = Final['operatorLabel'].str.normalize('NFKD').str.encode('ascii',
                                                                                         errors='ignore').str.decode(
            'utf-8')
        Final['fromSystem'] = Final['fromSystem'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode(
            'utf-8')
        Final['toSystem'] = Final['toSystem'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode(
            'utf-8')

        Final['value'] = pd.to_numeric(Final['value'])

        Final2 = Final.copy()
        # =======================================================
        # ===========================================================
        Final2.set_index('pointLabel', inplace=True)
        Final2['row'] = range(len(Final2))


        starts = Final2[['periodFrom', 'value', 'indicator', 'id', 'periodType',
                         'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey',
                         'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
                         'fromSystem',
                         'fromCountryCode', 'fromCountry', 'toSystem', 'toCountryCode',
                         'toCountry', 'row']].rename(columns={'periodFrom': 'Date'})

        ends = Final2[['periodTo', 'value', 'indicator', 'id', 'periodType',
                       'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey',
                       'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
                       'fromSystem',
                       'fromCountryCode', 'fromCountry', 'toSystem', 'toCountryCode',
                       'toCountry', 'row']].rename(columns={'periodTo': 'Date'})

        # ================================================================
        df_decomp = pd.concat([starts, ends]).drop_duplicates()
        df_decomp = df_decomp.set_index('row', append=True)
        df_decomp.sort_index()

        df_decomp = df_decomp.groupby(level=[0, 1]).apply(
            lambda x: x.set_index('Date').resample('D').fillna(method='pad'))
        df_decomp = df_decomp.reset_index(level=1, drop=True)
        df_decomp = df_decomp.reset_index()
        df_decomp = df_decomp.drop_duplicates()
        df_decomp = df_decomp.dropna()
        df_decomp = df_decomp.rename(columns={'Date': 'periodFrom'})


        df_decomp["periodTo"] = df_decomp["periodFrom"] + timedelta(days=1)
        self.df_decomp = df_decomp

        self.df_decomp['run_day'] = self.run_day
        for c in ['periodFrom', 'lastUpdateDateTime', 'periodTo', 'run_day']:
            self.df_decomp[c] = pd.to_datetime(self.df_decomp[c])

    def persist_to_mongo(self):
        self.data_adaptor.persist(self.df_decomp, self.run_day)

    @classmethod
    def retrieve(cls, t_range=None, query=None):
        logger.info(f'Retrieving...')
        data_adaptor = MongoAdapter()
        return data_adaptor.load_cache(t_range, query)
