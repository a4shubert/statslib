import logging
import pandas as pd
from pymongo import MongoClient

from gmt.fom.gas.shared import pathmap
from gmt.fom.gas.shared.config import config


logger = logging.getLogger(__file__)


class GasMongo(object):
    def __init__(self):
        self.client = self._connect()
        self.db = None
        self.collection = None

    def _connect(cls):
        mongo_kwargs = config.MONGO_DB._asdict()
        mongo_kwargs['tlsCAFile'] = pathmap.MONGO_AUTH_PEM
        client = MongoClient(mongo_kwargs.pop('uri'), **mongo_kwargs)

        db_list = client.list_database_names()
        if len(db_list) > 0:
            logger.debug('Connected successfully')
            return client
        else:
            raise ValueError('Please check connection to MongonDB')

    @property
    def databases(self):
        return self.client.list_database_names()

    @property
    def collections(self):
        if self.db is not None:
            return self._collections
        else:
            raise ValueError('Please choose database using get_db(name)')

    def choose_db(self, name):
        self.db = self.client[name]
        self.collections = self.db.collection_names()

    def choose_collection(self, name):
        if self.db is not None:
            if name not in self.collections:
                logger.info(f'Choosing collection {name}')
            self.collection = self.db[name]
        else:
            raise ValueError('Please choose database using choose_db(name)')

    def select_all(self):
        if self.collection is not None:
            records = [r for r in self.collection.find()]

            if len(records) > 0:
                df = pd.DataFrame(records).drop('_id', axis=1)
                df.columns = [
                    col.replace("\\u002e",
                                ".").replace("\\u0024",
                                             "\$").replace("\\\\", "\\")
                    for col in df.columns
                ]
                return df
            else:
                logger.info(
                    f'There is no data in the collection {self.collection.name}'
                )
        else:
            raise ValueError(
                'Please choose collection using choose_collection(name)')

    def select(self, query):
        if self.collection is not None:
            records = [r for r in self.collection.find(query)]
            df = pd.DataFrame(records).drop('_id', axis=1)
            df.columns = [
                col.replace("\\u002e",
                            ".").replace("\\u0024",
                                         "\$").replace("\\\\", "\\")
                for col in df.columns
            ]
            return df
        else:
            raise ValueError(
                'Please choose collection using choose_collection(name)')

    def pandas_to_mongo(self, df):
        if self.collection is not None:
            if isinstance(df, pd.Series):
                df = df.to_frame()
            if df.shape[0] > 0 :
                df.columns = [
                    col.replace("\\",
                                "\\\\").replace("\$",
                                                "\\u0024").replace(".", "\\u002e")
                    for col in df.columns
                ]
                logger.debug(f'Saving {df.shape[0]} rows to MongoDb')
                ids = self.collection.insert_many(df.to_dict('records'))
                return ids
            else:
                logger.info(f'DataFrame has no rows')
        else:
            raise ValueError(
                'Please choose collection using choose_collection(name)')

    def clear_collection(self):
        if self.collection is not None:
            self.collection.delete_many({})

    @collections.setter
    def collections(self, value):
        self._collections = value



