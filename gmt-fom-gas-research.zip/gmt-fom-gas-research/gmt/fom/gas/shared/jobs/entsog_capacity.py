import logging

from gmt.fom.gas import config
from gmt.fom.gas.shared.data_sources.entsog_capacity import EntsogCapacityDataScrapper
from gmt.fom.gas.shared.utils.common import report_run_time
from gmt.fom.gas.shared.utils.mail import send_mail

logger = logging.getLogger(__file__)


@report_run_time(long_format=False)
def job_entsog_capacity_data_scrapping():
    logger.info(
        f'\nRunning entsog capacity data scrapping'
    )
    try:
        dataScrapper = EntsogCapacityDataScrapper()
        dataScrapper.query_data()
        dataScrapper.filter_columns()
        dataScrapper.convert_columns()
        dataScrapper.country_connection_id()
        dataScrapper.from_country_data()
        dataScrapper.other_countries_connection_id()
        dataScrapper.combine()
        dataScrapper.persist_to_mongo()
        status = 'SUCCESS'
    except Exception as e:
        logger.exception(e)
        status = 'FAILED'

    send_mail(from_=config.MAIL_ADMIN,
              to_=config.MAIL_ADMIN,
              subject=f'Entsog_capacity_data_scrapping_{status}',
              text=f'Scrapping @ mongo',
              server=config.MAIL_SERVER)


if __name__ == '__main__':
    job_entsog_capacity_data_scrapping()
