import logging
import multiprocessing as mp
import os
from datetime import date

from pathos.pools import _ThreadPool as Pool

from gmt.fom.gas import config
from gmt.fom.gas.shared.models.git_storage.calibrator import Calibrator
from gmt.fom.gas.shared.models.git_storage.data.adapter import DataAdapter
from gmt.fom.gas.shared.models.git_storage.data.fwd import Forward
from gmt.fom.gas.shared.models.git_storage.data.ir import Ir
from gmt.fom.gas.shared.models.git_storage.diffusion import Diffusion
from gmt.fom.gas.shared.models.git_storage.model import GitStorageModel
from gmt.fom.gas.shared.models.git_storage.storage import Storage
from gmt.fom.gas.shared.utils.common import report_run_time
from gmt.fom.gas.shared.utils.mail import send_mail

logger = logging.getLogger(__file__)
file_folder = os.path.dirname(__file__)


def _val_one_storage(val_date, storage, diffusion, calibrator):
    try:
        logger.info(f'Working_{storage.storage_id} storage...')

        # Market
        ir = Ir(start_date=val_date,
                ccy=storage.ccy)

        forward = Forward(
            start_date=val_date,
            curve_name=storage.fwd_curve,
            smooth_curve=False,
            apply_weekend_shaping=True,
            weekend_shaping_factor=0.999)

        myModel = GitStorageModel(val_date=val_date,
                                  inventory=storage.inventory,
                                  discount_deltas=False,
                                  ir=ir,
                                  forward=forward,
                                  storage=storage,
                                  diffusion=diffusion,
                                  calibrator=calibrator
                                  )

        myModel.fit()
        return myModel
    except Exception as e:
        logger.debug(f'\n\n{storage.storage_id}: {storage.storage_type.value}: FAILED\n\n')
        logger.exception(e)
        return f'{storage.storage_id}: {storage.storage_type.value}: FAILED\n\n'


@report_run_time(long_format=False)
def job_git_storage_pooled(num_processes=None):
    val_date = date.today().strftime(format='%Y-%m-%d')
    error_msg = ''
    try:
        # valuation date
        diffusion = Diffusion(
            **DataAdapter.get_diffusion_params()
        )

        calibrator = Calibrator(
            **DataAdapter.get_calibrator_params()
        )

        storages = DataAdapter.get_all_storages()

        # Valuation (pooled)
        if num_processes is None:
            num_processes = mp.cpu_count()
        pool = Pool(processes=num_processes)

        results = []
        for storage in storages:
            # Storage
            storage = Storage(**storage)

            results.append(
                pool.apply_async(
                    _val_one_storage, args=(val_date, storage, diffusion, calibrator)
                )
            )
        pool.close()
        pool.join()
        fitted_models = [r.get() for r in results]

        for model in fitted_models:
            if isinstance(model, str):
                error_msg += model
            else:
                model.save_results()
        status = 'SUCCESS'

    except Exception as e:
        logger.exception(e)
        status = 'FAILED'

    send_mail(from_=config.MAIL_ADMIN,
              to_=config.MAIL_ADMIN,
              subject=f'GitStorageModel_run_{status}',
              text=f'Model run: {val_date}' + f'\n\n{error_msg}',
              server=config.MAIL_SERVER)


if __name__ == '__main__':
    job_git_storage_pooled()