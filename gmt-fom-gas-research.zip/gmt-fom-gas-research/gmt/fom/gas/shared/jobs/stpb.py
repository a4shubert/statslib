import logging
import os
from datetime import date

from gmt.fom.gas import config
from gmt.fom.gas.shared.utils.mail import send_mail
from gmt.fom.gas.shared.utils.common import report_run_time
from gmt.fom.gas.shared.models.stpb import model

logger = logging.getLogger(__file__)
file_folder = os.path.dirname(__file__)

@report_run_time(long_format=False)
def job_stpb():
    try:
        asof = date(2021, 2, 14)
        myModel = model.ShortTermPowerBurnModel(asof=asof,
                                                recalibrate=True)
        myModel.fit()
        myModel.forecast(horizon=14)
        status = 'SUCCESS'

    except Exception as e:
        logger.exception(e)
        status = 'FAILED'

    send_mail(from_=config.MAIL_ADMIN,
              to_=config.MAIL_ADMIN,
              subject=f'STPB_model{status}',
              text=f'Model run: {asof} : @ mongo',
              server=config.MAIL_SERVER)

    return myModel


if __name__ == '__main__':
    myModel = job_stpb()
    print(myModel.forecast_vals)
