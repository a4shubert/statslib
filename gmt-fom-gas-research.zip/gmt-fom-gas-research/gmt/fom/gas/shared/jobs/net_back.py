import logging
from datetime import date

import pandas as pd

from gmt.fom.gas import config
import gmt.fom.gas.shared.models.net_back.model as model
from gmt.fom.gas.shared.utils.common import report_run_time
from gmt.fom.gas.shared.utils.mail import send_mail

logger = logging.getLogger(__file__)


@report_run_time(long_format=False)
def job_net_back_model():
    # Job Parameters:
    start_date = date(2018, 1, 2)
    end_date = (date.today() - pd.DateOffset(days=1)).date()

    use_cache = True
    run_type = model.RunTypeEnum.CONSECUTIVELY

    logger.info(
        f'\nRunning NetBackModel from {start_date.strftime("%Y-%m-%d")} '
        f'to {end_date.strftime("%Y-%m-%d")} with cache={use_cache} and run_type={run_type.value}\n'
    )
    try:

        nb_model = model.NetBackModel(start_date, end_date, root_path=None)
        nb_model.fit()
        nb_model.forecast(use_cache=True, run_type=run_type)

        status = 'SUCCESS'

    except Exception as e:
        logger.exception(e)
        status = 'FAILED'

    send_mail(from_=config.MAIL_ADMIN,
              to_=config.MAIL_ADMIN,
              subject=f'NetBackModel_mongo_{status}',
              text=f'Model run: {start_date} : {end_date} @ mongo',
              server=config.MAIL_SERVER)


if __name__ == '__main__':
    job_net_back_model()
