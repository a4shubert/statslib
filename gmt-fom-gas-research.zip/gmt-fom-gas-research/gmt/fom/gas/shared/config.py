import logging
import os
import yaml

from logging import handlers

from gmt.fom.gas.shared.utils.common import to_namedtuple
from gmt.fom.gas.shared import pathmap

config_path = os.path.join(os.path.dirname(__file__), 'config.yaml')
config = yaml.load(open(config_path), Loader=yaml.FullLoader)
config = to_namedtuple(config, recursive=True)

logger = logging.getLogger()
logger.setLevel(config.LOG_CONFIG.level_debug)

console_handler = logging.StreamHandler()
console_handler.setLevel(config.LOG_CONFIG.level_info)

log_path = os.path.join(pathmap.LOG_FOLDER, 'log_debug.txt')
file_handler_debug = handlers.TimedRotatingFileHandler(log_path, 'midnight',
                                                       31)
file_handler_debug.setLevel(config.LOG_CONFIG.level_debug)

log_path = os.path.join(pathmap.LOG_FOLDER, 'log_info.txt')
file_handler_info = handlers.TimedRotatingFileHandler(log_path, 'midnight', 31)
file_handler_info.setLevel(config.LOG_CONFIG.level_info)

formatter = logging.Formatter(config.LOG_CONFIG.format)
console_handler.setFormatter(formatter)
file_handler_debug.setFormatter(formatter)
file_handler_info.setFormatter(formatter)

logger.addHandler(console_handler)
logger.addHandler(file_handler_debug)
logger.addHandler(file_handler_info)
