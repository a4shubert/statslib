import os

LIB_FOLDER = os.path.dirname(__file__)
LOG_FOLDER = os.path.abspath(os.path.join(LIB_FOLDER, '../../../..',
                                          'logs'))
if not os.path.exists(LOG_FOLDER):
    os.mkdir(LOG_FOLDER)

MONGO_AUTH_PEM = os.path.join(LIB_FOLDER, 'data_sources', 'mongo', 'auth',
                              'GMT-RootCA.pem')
