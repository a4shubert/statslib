import logging

import pandas as pd
from gmt.fom.gas.shared.models.git_storage.data.adapter import DataAdapter
logger = logging.getLogger(__file__)


class Ir:


    def __init__(self, start_date,  ccy):
        self.start_date = start_date
        self.ccy = ccy
        self.data_adapter = DataAdapter()
        self._curve = self._format_ir_curve(self._get_ir_curve())

    @property
    def curve(self):
        return self._curve

    def _get_ir_curve(self) -> pd.DataFrame:
        logger.info('Getting IR curve data...')
        ir_curve = self.data_adapter.get_ir_data(ccy=self.ccy, day=self.start_date)
        return ir_curve

    def _format_ir_curve(self, ir_curve: pd.DataFrame) -> pd.Series:
        logger.info('Format ir curve ...')
        ir_curve['date'] = pd.to_datetime(ir_curve['date'], format='%d/%m/%Y')
        ir_curve = ir_curve.set_index('date')
        ir_curve.index = pd.PeriodIndex(ir_curve.index, freq='D')
        ir_curve = ir_curve.resample('D').asfreq('D').interpolate(method='linear').squeeze()
        return ir_curve
