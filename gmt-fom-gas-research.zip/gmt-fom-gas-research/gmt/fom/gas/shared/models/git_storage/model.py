import logging
import os

import matplotlib.pyplot as plt
import pandas as pd
from cmdty_storage import three_factor_seasonal_value

from gmt.fom.gas import config
from gmt.fom.gas.shared.models.git_storage.calibrator import Calibrator
from gmt.fom.gas.shared.models.git_storage.data.adapter import DataAdapter
from gmt.fom.gas.shared.models.git_storage.data.fwd import Forward
from gmt.fom.gas.shared.models.git_storage.data.ir import Ir
from gmt.fom.gas.shared.models.git_storage.diffusion import Diffusion
from gmt.fom.gas.shared.models.git_storage.storage import Storage

logger = logging.getLogger(__file__)
file_folder = os.path.dirname(__file__)

class GitStorageModel(object):
    class Results:
        def __init__(self,
                     val_date,
                     full_value,
                     intr_value,
                     extr_value,
                     deltas_frame,
                     trigger_prices_frame,
                     intrinsic_profile,
                     expected_profile,
                     storage_id,
                     storage_type,
                     ):
            self.val_date = val_date
            self.full_value = full_value
            self.intr_value = intr_value
            self.extr_value = extr_value
            self.deltas_frame = deltas_frame
            self.trigger_prices_frame = trigger_prices_frame
            self.intrinsic_profile = intrinsic_profile
            self.expected_profile = expected_profile
            self.combined = self.intrinsic_profile['inject_withdraw_volume'].to_frame().join(
                self.expected_profile['inject_withdraw_volume'].rename('ext')
            ).join(self.trigger_prices_frame['fwd_price'].rename('fwd'))
            self.combined['run_date'] = pd.to_datetime(val_date)
            self.combined['storage_id'] = storage_id
            self.combined['storage_type'] = storage_type
            try:
                self.combined.index = self.combined.index.to_timestamp()
            except Exception as e:
                pass
            self.combined.index.name = 'day'
            self.plots = []

            print(
                f'Full Value={self.full_value:,.4f}\nIntrinsic Value={self.intr_value:,.4f}\nExtrinsic Value={self.extr_value:,.4f}')

    def __init__(self,
                 val_date: str,
                 inventory: float,
                 discount_deltas: bool,

                 forward: Forward,
                 storage: Storage,
                 ir: Ir,

                 calibrator: Calibrator,
                 diffusion: Diffusion

                 ):
        self.data_adapter = DataAdapter()

        self.val_date = val_date
        self.inventory = inventory
        self.discount_deltas = discount_deltas

        # Interest rate curve
        self.ir = ir

        # Forward curve class
        self.forward = forward

        # Storage
        self.storage = storage

        # Calibrator
        self.calibrator = calibrator

        # Diffusion parameters
        self.diffusion = diffusion

        self.val_results_3f = None
        self.results = None

    @property
    def params(self):
        return dict(zip(['val_date', 'inventory', 'discount_deltas'],
                        [self.val_date, self.inventory, self.discount_deltas]))

    def fit(self):
        logger.info('Fitting...')
        self._compute()
        self._report()

    def _compute(self):
        self.val_results_3f = None
        try:
            val_results_3f = three_factor_seasonal_value(
                cmdty_storage=self.storage.cmdty_storage,
                val_date=self.val_date,
                inventory=self.inventory,
                fwd_curve=self.forward.curve,
                interest_rates=self.ir.curve,
                settlement_rule=self.calibrator.settlement_rule,
                num_sims=self.calibrator.num_sims,
                seed=self.calibrator.seed,
                spot_mean_reversion=self.diffusion.spot_mean_reversion,
                spot_vol=self.diffusion.spot_vol,
                long_term_vol=self.diffusion.long_term_vol,
                seasonal_vol=self.diffusion.seasonal_vol,
                basis_funcs=self.calibrator.basis_funcs,
                discount_deltas=False
            )
            self.val_results_3f = val_results_3f
        except Exception as e:
            logger.exception(e)
            raise e

    def _report(self):
        if self.val_results_3f is not None:
            logger.info('Generating reports....')
            intr_delta = self.val_results_3f.intrinsic_profile['net_volume']
            deltas_frame = pd.DataFrame(index=self.val_results_3f.deltas.index,
                                        data={'full_delta': self.val_results_3f.deltas,
                                              'intrinsic_delta': intr_delta})
            deltas_frame = deltas_frame

            active_fwd_curve = self.forward.curve[self.storage.cmdty_storage.start:
                                                  self.storage.cmdty_storage.end]
            trigger_prices_frame = self.val_results_3f.trigger_prices.copy()
            trigger_prices_frame['expected_inventory'] = self.val_results_3f.expected_profile['inventory']
            trigger_prices_frame['fwd_price'] = active_fwd_curve
            trigger_prices_frame = trigger_prices_frame

            full_value = self.val_results_3f.npv
            intr_value = self.val_results_3f.intrinsic_npv
            extr_value = self.val_results_3f.extrinsic_npv

            self.results = self.Results(
                val_date=self.val_date,
                full_value=full_value,
                intr_value=intr_value,
                extr_value=extr_value,
                deltas_frame=deltas_frame,
                trigger_prices_frame=trigger_prices_frame,
                intrinsic_profile=self.val_results_3f.intrinsic_profile,
                expected_profile=self.val_results_3f.expected_profile,
                storage_id=self.storage.storage_id,
                storage_type=self.storage.storage_type.value
            )

    def plot(self):
        if self.val_results_3f is not None:
            figsize = (6 * 1.6, 6)
            fig, ax_combined = plt.subplots()
            self.results.combined.inject_withdraw_volume.plot(figsize=figsize, ax=ax_combined)
            self.results.combined.ext.plot(ax=ax_combined)
            self.results.combined.fwd.rename('forward').plot(secondary_y=True, ax=ax_combined, label='forward')
            ax_combined.legend(['intrinsic', 'extrinsic', 'forward'], loc=0)
            ax_combined.set_title('Results')
            self.results.plots.append(fig)

            fig, ax = plt.subplots()
            ax_deltas = self.val_results_3f.deltas.plot(title='Daily Forward Deltas and Expected Inventory',
                                                        legend=True,
                                                        label='Delta', ax=ax)
            ax_deltas.set_ylabel('Delta')
            inventory_projection = self.val_results_3f.expected_profile['inventory']
            ax_inventory = inventory_projection.plot(secondary_y=True,
                                                     legend=True, ax=ax_deltas,
                                                     label='Expected Inventory',
                                                     figsize=figsize,
                                                     )
            h1, l1 = ax_deltas.get_legend_handles_labels()
            h2, l2 = ax_inventory.get_legend_handles_labels()
            ax_inventory.set_ylabel('Inventory')
            ax_deltas.legend(h1 + h2, l1 + l2, loc=1)
            self.results.plots.append(fig)
        else:
            print('Please run .fit() method!')

    def save_results(self):
        self.data_adapter._persist_results(
            self.results.combined.reset_index(),
            self.val_date,
            self.storage.storage_id,
            self.storage.storage_type.value)

    def email_results(self):
        if self.val_results_3f is not None:
            import io
            import pandas as pd
            import smtplib
            from email.mime.application import MIMEApplication
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
            from email.mime.image import MIMEImage

            def export_csv(df):
                with io.StringIO() as buffer:
                    df.to_csv(buffer)
                    return buffer.getvalue()

            def export_plot(fig):
                with io.BytesIO() as buff:
                    fig.savefig(buff)
                    im_bytes = buff.getvalue()
                    return im_bytes

            from_ = config.MAIL_ADMIN
            to_ = ';'.join(config.MAIL_GIT_STORAGE)
            subject = f'GitStorageModelRun_for_{self.storage.storage_id}_{self.val_date}_SUCCESS'
            text = f'Full Value = {self.results.full_value:,.0f}<p>Intrinsic Value = {self.results.intr_value:,.0f}<p>Extrinsic Value = {self.results.extr_value:,.0f}'
            server = config.MAIL_SERVER

            from_address = from_
            eml = MIMEMultipart()
            eml['From'] = from_address
            eml['To'] = to_
            eml['Subject'] = subject
            html_part = MIMEMultipart(_subtype='related')
            body = MIMEText("""
                            {}
                            <p><img src="cid:myimage"/></p><img src="cid:myimage2" />
                            """.format(text), _subtype='html')
            html_part.attach(body)
            msgImage = MIMEImage(export_plot(self.results.plots[1]), 'png')
            msgImage.add_header('Content-Id', '<myimage>')
            msgImage.add_header("Content-Disposition", "inline", filename="myimage")
            html_part.attach(msgImage)
            eml.attach(html_part)

            msgImage = MIMEImage(export_plot(self.results.plots[0]), 'png')
            msgImage.add_header('Content-Id', '<myimage2>')
            msgImage.add_header("Content-Disposition", "inline", filename="myimage2")
            html_part.attach(msgImage)
            eml.attach(html_part)

            attachment = MIMEApplication(export_csv(self.results.combined))
            attachment['Content-Disposition'] = 'attachment; filename="{}"'.format(
                f'GitStorageResults_{self.val_date}.csv')
            eml.attach(attachment)

            server = smtplib.SMTP(server)
            server.sendmail(from_address, to_, eml.as_string())
            server.quit()
            logger.debug('Sent email')
        else:
            print('Please fun .fit() method!')
