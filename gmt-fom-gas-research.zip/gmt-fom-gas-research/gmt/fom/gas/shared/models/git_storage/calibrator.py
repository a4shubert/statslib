def settlement_rule(delivery_date):
    return delivery_date.asfreq('M').asfreq('D', 'end') + 20


class Calibrator:
    def __init__(self,

                 num_sims=1000,
                 basis_funcs='1 + x_st + x_sw + x_lt + x_st ** 2 + x_sw ** 2 + x_lt ** 2 + x_st ** 3 + x_sw ** 3 + x_lt ** 3',
                 seed=11,
                 seed_is_random=False,
                 fwd_sim_seed=13,
                 set_fwd_sim_seed=True,
                 extra_decisions=0,
                 num_inventory_grid_points=100,
                 numerical_tolerance=1e-10
                 ):
        self.num_sims = num_sims
        self.basis_funcs = basis_funcs
        self.seed = seed
        self.seed_is_random = seed_is_random
        self.fwd_sim_seed = fwd_sim_seed
        self.set_fwd_sim_seed = set_fwd_sim_seed
        self.extra_decisions = extra_decisions
        self.num_inventory_grid_points = num_inventory_grid_points
        self.numerical_tolerance = numerical_tolerance
        self.settlement_rule = settlement_rule

    @property
    def params(self):
        return dict(
            zip(['num_sims', 'basis_funcs', 'seed',
                 'seed_is_random', 'fwd_sim_seed', 'set_fwd_sim_seed', 'extra_decisions',
                 'num_inventory_grid_points', 'numerical_tolerance',
                 ],
                [

                    self.num_sims, self.basis_funcs, self.seed, self.seed_is_random, self.fwd_sim_seed,
                    self.set_fwd_sim_seed, self.extra_decisions, self.num_inventory_grid_points,
                    self.numerical_tolerance,
                    ]))
