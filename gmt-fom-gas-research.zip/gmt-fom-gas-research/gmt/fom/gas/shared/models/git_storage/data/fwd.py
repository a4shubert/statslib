import itertools
import logging

import pandas as pd
from curves import adjustments, max_smooth_interp

from gmt.fom.gas.shared.models.git_storage.data.adapter import DataAdapter


logger = logging.getLogger(__file__)

CONVERSION_CONSTANT = 29.3071


class Forward:

    def __init__(self,
                 start_date,
                 curve_name,
                 smooth_curve=True,
                 apply_weekend_shaping=True,
                 weekend_shaping_factor=0.995,
                 ):
        self.start_date = start_date
        self.smooth_curve = smooth_curve
        self.apply_weekend_shaping = apply_weekend_shaping
        self.weekend_shaping_factor = weekend_shaping_factor
        self.curve_name = curve_name
        self.data_adapter = DataAdapter()
        self._curve = self._format_fwd_curve(self._get_fwd_data())

    @property
    def params(self):
        return dict(zip(['smooth_curve', 'apply_weekend_shaping', 'weekend_shaping_factor', 'curve_name'],
                        [self.smooth_curve, self.apply_weekend_shaping, self.weekend_shaping_factor, self.curve_name]))

    @property
    def curve(self):
        return self._curve

    def _get_fwd_data(self) -> pd.DataFrame:
        logger.info('Getting forward curve data...')
        fwd_curve = self.data_adapter.get_forward_data(curve=self.curve_name, day=self.start_date)
        return fwd_curve


    def _format_fwd_curve(self, fwd_curve: pd.DataFrame) -> pd.Series:
        logger.info('Format forward curve...')
        freq = 'D'
        fwd_periods = []
        fwd_prices = []

        for fwd_start, fwd_price in fwd_curve.values.tolist():
            fwd_periods.append(pd.Period(fwd_start, freq=freq))
            fwd_prices.append(fwd_price)

        if self.smooth_curve:
            p1, p2 = itertools.tee(fwd_periods)
            next(p2, None)
            contracts = []
            for start, end, price in zip(p1, p2, fwd_prices):
                contracts.append((start, end - 1, price))
            weekend_adjust = None
            if self.apply_weekend_shaping:
                weekend_adjust = adjustments.dayofweek(default=1.0,
                                                       saturday=self.weekend_shaping_factor,
                                                       sunday=self.weekend_shaping_factor)

            fwd_curve = max_smooth_interp(contracts,
                                          freq=freq,
                                          mult_season_adjust=weekend_adjust)
        else:
            fwd_curve = pd.Series(fwd_prices, pd.PeriodIndex(fwd_periods)).resample('D').fillna('pad')
        return fwd_curve * CONVERSION_CONSTANT


if __name__ == '__main__':
    forward = Forward('gbp', True, True, 0.999)
    res = forward.curve
