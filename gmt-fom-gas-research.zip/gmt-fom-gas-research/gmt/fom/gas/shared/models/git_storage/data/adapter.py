import logging
import os

import pandas as pd

from gmt.fom.gas.shared.data_sources.mongo import GasMongo
from gmt.fom.gas.shared.models.git_storage.storage import Storage
from gmt.fom.gas.shared.statslib.utils.file import read_from_json
from gmt.dna.datagateway.data_adapter_factory import DataAdapterFactory

logger = logging.getLogger(__file__)


class DataAdapter:
    GAS_MODELS_DB = 'GasModels'
    GIT_STORAGE_COLLECTION = 'gitstorage'
    RUN_DATE = 'run_date'
    STORAGE_ID = 'storage_id'
    STORAGE_TYPE = 'storage_type'

    def __init__(self):
        self.mongo = GasMongo()
        self.mongo.choose_db(DataAdapter.GAS_MODELS_DB)

    @classmethod
    def get_calibrator_params(cls):
        _FOLDER = r'\\trading1\Common\gasmodels\git_storage\production'
        _FILE = 'calibrator.json'
        return read_from_json(os.path.join(_FOLDER, _FILE))

    @classmethod
    def get_diffusion_params(cls):
        _FOLDER = r'\\trading1\Common\gasmodels\git_storage\production'
        _FILE = 'diffusion.json'
        return read_from_json(os.path.join(_FOLDER, _FILE))

    @classmethod
    def get_all_storages(cls):
        """
        retrieve all storages from the folder
        """
        _FOLDER = r"\\trading1\Common\gasmodels\git_storage\production\storages"
        storage__FOLDERs = [os.path.join(_FOLDER, f) for root, subfs, files in os.walk(_FOLDER) for f in files]
        all_storages = []
        for pth in storage__FOLDERs:
            storage_id = os.path.split(pth)[-1].split('.')[0]
            xl = pd.ExcelFile(pth)
            storage = xl.parse(xl.sheet_names[0])
            ratchets = xl.parse(xl.sheet_names[1])
            storages = storage.to_dict(orient='index').values()
            for store in storages:
                store['storage_id'] = storage_id
                if store['ratchets (Y/N)'] == 'Y':
                    store['ratchets'] = Storage.format_ratchets_data(ratchets)
                    store['storage_type'] = 'RATCHETS'
                else:
                    store['storage_type'] = 'SIMPLE'
                del store['ratchets (Y/N)']
                all_storages.append(store)
            xl.close()
        return all_storages

    @classmethod
    def get_forward_data(cls, curve, day):
        d = DataAdapterFactory.create("arc", env='prod')
        fwd_curve = d.get_forward_curve(curve, day).reset_index()
        fwd_curve.set_index('index').resample('D').sum().reset_index()
        return fwd_curve.head(300)

    @classmethod
    def get_ir_data(cls, ccy, day):
        """
        IR_GBP, IR_EUR, ...
        """
        d = DataAdapterFactory.create("arc", env='prod')
        ir_curve = pd.DataFrame()
        ir_curve = d.get_forward_curve(f'IR_{ccy.upper()}', day).reset_index()
        ir_curve.columns = ['date', ccy.upper()]
        return ir_curve

    @property
    def results_t_range(self):
        self.mongo.choose_collection(DataAdapter.GIT_STORAGE_COLLECTION)
        t_range = self.mongo.collection.distinct(
            DataAdapter.RUN_DATE)
        t_range = [t.date() for t in t_range]
        return t_range

    def _persist_results(self, result, t, storage_id, storage_type):
        self.mongo.choose_collection(DataAdapter.GIT_STORAGE_COLLECTION)
        self.mongo.collection.delete_many(
            {DataAdapter.RUN_DATE: pd.to_datetime(t),
             DataAdapter.STORAGE_ID: storage_id,
             DataAdapter.STORAGE_TYPE: storage_type}
        )
        if result is not None and result.shape[0] > 0:
            self.mongo.pandas_to_mongo(result)
        else:
            logger.info(f'Empty dataFrame for t={t}')

    def retrieve(self, t_range=None, query=None):
        self.mongo.choose_collection(DataAdapter.GIT_STORAGE_COLLECTION)
        if query is None:
            res = pd.concat([
                self.mongo.select({DataAdapter.RUN_DATE: pd.to_datetime(t)})
                for t in t_range],
                axis=0)
        else:
            res = self.mongo.select(query)
        return res.set_index('day')
