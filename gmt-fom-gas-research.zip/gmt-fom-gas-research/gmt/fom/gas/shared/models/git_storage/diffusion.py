class Diffusion:
    def __init__(self, spot_mean_reversion, spot_vol, long_term_vol, seasonal_vol):
        self.spot_mean_reversion = spot_mean_reversion
        self.spot_vol = spot_vol
        self.long_term_vol = long_term_vol
        self.seasonal_vol = seasonal_vol

    @property
    def params(self):
        return dict(
            zip(['spot_mean_reversion', 'spot_vol', 'long_term_vol', 'seasonal_vol'],
                [
                    self.spot_mean_reversion, self.spot_vol, self.long_term_vol, self.seasonal_vol]))
