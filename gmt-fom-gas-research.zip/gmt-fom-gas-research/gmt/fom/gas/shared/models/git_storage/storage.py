import os
from enum import Enum

import pandas as pd
from cmdty_storage import CmdtyStorage, RatchetInterp


class StorageType(Enum):
    SIMPLE = 'SIMPLE'
    RATCHETS = 'RATCHETS'


class Storage:
    _FOLDER = r'\\trading1\Common\gasmodels\git_storage\data\input'
    _FILE = 'storage_ratchets.csv'
    _RATCHETS_PATH = os.path.join(_FOLDER, _FILE)

    def __init__(self,
                 storage_type,
                 storage_id,
                 ccy,
                 fwd_curve,
                 freq,
                 inventory,
                 storage_start,
                 storage_end,
                 injection_cost=0.0,
                 withdrawal_cost=0.0,
                 cmdty_consumed_inject=0.0,
                 cmdty_consumed_withdraw=0.0,
                 inj_consumed_pctg=0.0,
                 with_consumes_pctg=0.0,
                 ratchets = None,

                 # Specific to SIMPLE type:
                 min_inventory=0.0,
                 max_inventory=0.0,
                 max_injection_rate=0.0,
                 max_withdrawal_rate=0.0,
                 terminal_storage_npv=None,
                 ):
        self.storage_id = storage_id
        self.ccy = ccy
        self.fwd_curve = fwd_curve
        self.storage_type = storage_type
        self.freq = freq
        self.inventory = inventory
        self.storage_start = storage_start  # datetime.strptime(storage_start, '%d/%m/%Y').date()
        self.storage_end = storage_end  # datetime.strptime(storage_end, '%d/%m/%Y').date()
        self.injection_cost = injection_cost
        self.withdrawal_cost = withdrawal_cost
        self.cmdty_consumed_inject = cmdty_consumed_inject
        self.cmdty_consumed_withdraw = cmdty_consumed_withdraw
        self.inj_consumed_pctg = inj_consumed_pctg
        self.with_consumes_pctg = with_consumes_pctg
        self.terminal_storage_npv = terminal_storage_npv
        self.ratchets = ratchets

        # Specific to SIMPLE type:
        self.min_inventory = min_inventory
        self.max_inventory = max_inventory
        self.max_injection_rate = max_injection_rate
        self.max_withdrawal_rate = max_withdrawal_rate

        # cmdty-package object
        self.cmdty_storage = None

        try:
            self.storage_type = StorageType[self.storage_type]
        except KeyError:
            print('Please use SIMPLE or RATCHETS string as storage type!')
            raise KeyError()

        if self.storage_type is StorageType.RATCHETS:
            if self.ratchets is None:
                self.ratchets = self.format_ratchets_data(self.get_ratchets_data())
            self.cmdty_storage = CmdtyStorage(
                freq=self.freq,
                storage_start=self.storage_start,
                storage_end=self.storage_end,
                injection_cost=self.injection_cost,
                withdrawal_cost=self.withdrawal_cost,
                ratchets=self.ratchets,
                ratchet_interp=RatchetInterp.LINEAR,
                terminal_storage_npv=self.terminal_storage_npv,
            )

        if self.storage_type is StorageType.SIMPLE:
            self.cmdty_storage = CmdtyStorage(
                freq=self.freq,
                storage_start=self.storage_start,
                storage_end=self.storage_end,
                injection_cost=self.injection_cost,
                withdrawal_cost=self.withdrawal_cost,
                min_inventory=self.min_inventory,
                max_inventory=self.max_inventory,
                max_injection_rate=self.max_injection_rate,
                max_withdrawal_rate=self.max_withdrawal_rate,
                terminal_storage_npv=self.terminal_storage_npv
            )


    def get_ratchets_data(self):
        ratchets = pd.read_csv(Storage._RATCHETS_PATH)
        return ratchets

    @classmethod
    def format_ratchets_data(cls, _ratchets: pd.DataFrame):
        days = _ratchets['date'].dropna().unique()
        all_ratchets = []
        for day in days:
            freq = 'D'
            a = pd.Period(pd.to_datetime(day), freq=freq)
            bs = _ratchets.fillna(method='ffill').set_index('date').loc[day].values.tolist()
            ratchet = (a, [tuple(b) for b in bs])
            all_ratchets.append(ratchet)
        return all_ratchets
