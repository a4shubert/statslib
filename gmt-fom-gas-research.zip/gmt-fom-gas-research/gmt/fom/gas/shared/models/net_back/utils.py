from functools import reduce


class Utils(object):
    @classmethod
    def compose(cls, *functions):
        return reduce(lambda f, g: lambda x: f(g(x)), functions, lambda x: x)

    @classmethod
    def util_col_to_str(cls, r):
        return '_'.join([
            r.upper()
            for r in ' '.join("".join([c if c.isalnum() else " "
                                       for c in r]).strip().split()).split(' ')
        ])