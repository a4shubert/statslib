import os
import shutil
from enum import Enum

import pandas as pd
import logging
from gmt.fom.gas.shared.models.net_back.model import NetBackModel, NetBackSymbols
from gmt.fom.gas.shared.data_sources.mongo import GasMongo



logger = logging.getLogger(__file__)


def DataAdaptor(root_path=None, run_t=None):
    if root_path:
        data_adaptor = FileAdaptor(root_path, run_t)
        logger.info('Using File adaptor')
    else:
        data_adaptor = MongoAdapter()
        logger.info('Using MongoDb adaptor')
    return data_adaptor


class FileAdaptor:

    def __init__(self, root_path, run_t=None):

        self.alias = DataAdaptorAlias.FILE
        self.root_path = root_path
        self.cache_path = os.path.join(root_path, 'cache')
        if not os.path.exists(self.cache_path):
            os.mkdir(self.cache_path)
        if run_t:
            self.data_path = os.path.join(root_path, 'data')
            run_t = run_t.strftime(NetBackModel.Mappings.format_t_short)
            run_path = os.path.join(self.root_path, 'run')
            if not os.path.exists(run_path):
                os.mkdir(run_path)
            out_path = os.path.join(run_path, run_t)
            if os.path.exists(out_path):
                shutil.rmtree(out_path)
            logger.info(f'Out_path: {out_path}')
            if not os.path.exists(out_path):
                os.mkdir(out_path)
            self.out_path = out_path

    @property
    def cached_t_range(self):
        fls = [fls for root, subf, fls in os.walk(self.cache_path)][0]
        t_range = [
            pd.to_datetime(f,
                           format=NetBackModel.Mappings.format_t_short).date()
            for f in fls
        ]
        return t_range

    def persist(self, cache, t):
        cache_file_name = pd.Timestamp(t).strftime(
            NetBackModel.Mappings.format_t_short)
        if cache is not None:
            cache.to_csv(os.path.join(self.cache_path, cache_file_name),
                         index=False)
        else:
            logger.info(f'Empty dataFrame for t={t}')

    def load_cache(self, t_range, query=None):
        t_range = [
            t.strftime(NetBackModel.Mappings.format_t_short) for t in t_range
        ]
        fls = [fls for root, subf, fls in os.walk(self.cache_path)][0]
        fls = [f for f in fls if f in t_range]

        if len(fls) > 0:
            res = pd.concat([
                pd.read_csv(
                    os.path.join(self.cache_path, f),
                    parse_dates=NetBackModel.Mappings.mask_date_type_columns)
                for f in fls
            ],
                axis=0, sort=True)
            return res
        else:
            return None

    def load_variables(self):
        data = pd.read_csv(
            os.path.join(self.data_path,
                         NetBackModel.Mappings.source_file_name_variables))
        return data

    def load_costs(self):
        data = pd.read_csv(
            os.path.join(self.data_path,
                         NetBackModel.Mappings.source_file_name_costs))
        return data


class MongoAdapter:
    GAS_MODELS_DB = 'GasModels'
    NETBACK_VARIABLES_COLLECTION = 'netback_variables'
    NETBACK_COSTS_COLLECTION = 'netback_costs'
    NETBACK_RESULTS = 'netback_results'

    def __init__(self):
        self.alias = DataAdaptorAlias.MONGO
        self.mongo = GasMongo()
        self.mongo.choose_db(MongoAdapter.GAS_MODELS_DB)

    @property
    def cached_t_range(self):
        self.mongo.choose_collection(MongoAdapter.NETBACK_RESULTS)
        t_range = self.mongo.collection.distinct(
            NetBackSymbols.SYM_EFFECTIVEDATE)
        t_range = [t.date() for t in t_range]
        return t_range

    def persist(self, cache, t):
        self.mongo.choose_collection(MongoAdapter.NETBACK_RESULTS)
        self.mongo.collection.delete_many(
            {NetBackSymbols.SYM_EFFECTIVEDATE: pd.to_datetime(t)})
        if cache is not None and cache.shape[0] > 0:
            self.mongo.pandas_to_mongo(cache)
        else:
            logger.info(f'Empty dataFrame for t={t}')

    def load_cache(self, t_range, query=None):
        self.mongo.choose_collection(MongoAdapter.NETBACK_RESULTS)
        if query is None:
            res = pd.concat([
                self.mongo.select({NetBackSymbols.SYM_EFFECTIVEDATE: pd.to_datetime(t)})
                for t in t_range],
                axis=0)
        else:
            res = self.mongo.select(query)
        return res

    def load_variables(self):
        self.mongo.choose_collection(
            MongoAdapter.NETBACK_VARIABLES_COLLECTION)
        data = self.mongo.select_all()
        return data

    def load_costs(self):
        self.mongo.choose_collection(MongoAdapter.NETBACK_COSTS_COLLECTION)
        data = self.mongo.select_all()
        return data


class DataAdaptorAlias(Enum):
    FILE = 'FILE'
    MONGO = 'MONGO'
