"""
Notes on the structure:
 * NetBackModel class has
   - create/transform methods, which are private;
   - each transform method is using a composition of transformations in the form of (g o f)(x) = g(f(x))
   - make methods, which are public;
   - fit method gathers and transform source data
   - forecast method is using a modified deep copy of the main instance to iterate over the time-ticks
     thus separating the main instance attributes and the time-tick model's attributes
   - retrieve method stores the netback and netback_narrow dataFrames as well as pivoted by terminal results

 * run() function
   - executes both fit(), forecast() and postprocess() methods in one-go

 * Google's yapf (https://github.com/google/yapf) formatter was used to format this file to PEP8

* Model documentation: https://wiki/display/gqd/Netback+model
"""

import logging
import multiprocessing as mp
import os
from datetime import (datetime, date, timedelta)
from enum import Enum
from functools import partial

import numpy as np
import pandas as pd
from gmt.dna.datagateway.data_adapter_factory import DataAdapterFactory
from pathos.pools import _ThreadPool as Pool


from gmt.fom.gas.shared.models.net_back.utils import Utils

logger = logging.getLogger(__file__)


class NetBackSymbols(object):
    # COSTS csv
    SYM_BALLAST_SPEED_KNOTS = "Ballast - Speed (knots)"
    SYM_DAYS_IN_PORT = "Days in port"
    SYM_FUEL_CONSUMPTION_IN_PORT_TONNES_DAY = "Fuel consumption in port (tonnes/day)"
    SYM_FUEL_OIL_CONSUMPTION_TONNES_DAY = "Fuel oil consumption (tonnes/day)"
    SYM_FUEL_SHARE_FUEL_OIL_FOR_STEAM_TURBINE = "Fuel Share - Fuel oil for steam turbine"
    SYM_FUEL_SHARE_LNG_BOIL_OFF_FOR_STEAM_TURBINE = "Fuel Share - LNG boil-off for steam turbine"
    SYM_HEEL_M3 = "Heel (M3)"
    SYM_HEEL_MMBTU = "Heel (mmbtu)"
    SYM_LADEN_BOIL_OFF_MCM_D = "Laden - Boil-off (Mcm/d)"
    SYM_LADEN_BOIL_OFF_MMBTU_D = "Laden - Boil-off (mmbtu/d)"
    SYM_LADEN_NATURAL_BOIL_OFF_GAS_DAY = "Laden - Natural boil-off gas (%/day)"
    SYM_LADEN_SPEED_KNOTS = "Laden - Speed (knots)"
    SYM_LOADED_GAS_CARGO_MCM_GAS = "Loaded - Gas cargo (Mcm Gas)"
    SYM_LOADED_GAS_CARGO_MMBTU = "Loaded - Gas cargo (mmbtu)"
    SYM_ONEWAY_CANAL_TRANSIT_DAYS = "OneWay - Canal Transit (days)"
    SYM_ONEWAY_PORT_CHARGES_LOAD_DISCHARGE_USD = "OneWay - Port charges (Load+Discharge) (USD)"
    SYM_ONEWAY_PORT_TURNAROUND_COST = "OneWay - Port Turnaround Cost"
    SYM_ONEWAY_PORT_TURNAROUND_TIME_LOAD_DISCHARGE_DAYS = "OneWay - Port turnaround time (Load+Discharge) (days)"
    SYM_OPERATING_COST_USD_DAY = "Operating cost (USD/day)"
    SYM_PANAMA_BALLAST = "Panama - Ballast ($)"
    SYM_PANAMA_LADEN = "Panama - Laden ($)"
    SYM_PANAMA_TOTAL = "Panama - Total ($)"
    SYM_PILOT_LIGHT_FUEL_CONS_TONNES_DAY = "Pilot Light Fuel Cons (tonnes/day)"
    SYM_SHIP_SIZE_M3 = "Ship Size (M3)"
    SYM_SPOT_CHARTER_RATE_USD_DAY = "Spot charter rate (USD/day)"
    SYM_SUEZ_BALLAST = "Suez - Ballast ($)"
    SYM_SUEZ_LADEN = "Suez - Laden ($)"
    SYM_SUEZ_TOTAL = "Suez - Total ($)"
    SYM_USD_TONNE_HFO = "USD/tonne - HFO"

    # VARIABLES csv
    SYM_ADD_DAYS = "Add days"
    SYM_BOIL_OFF = "Boil-off"
    SYM_CANAL_FEE = "Canal Fee"
    SYM_DAYS_TRAVEL_ONE_WAY_INC_TRANSIT = "Days Travel (one-way inc. transit)"
    SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT = "Days Travel (Return - inc. time at port)"
    SYM_DAYS_TRAVEL_TEMP = "Days Travel temp"
    SYM_DELIVERED_VOLUME = "Delivered Volume"
    SYM_DISTANCES = "Distances"
    SYM_PORT_CHARGES = "Port Charges"
    SYM_REGAS_COSTS = "Regas Costs"
    SYM_REGIONCODE = "RegionCode"
    SYM_REGIONFROM = "RegionFrom"
    SYM_TERMINALFROM = "TerminalFrom"
    SYM_TERMINALTO = "TerminalTo"
    SYM_ORIGINPRICECURVE = "OriginPriceCurve"
    SYM_SHIPPINGCOSTOUTPUT = "ShippingCostOutput"
    SYM_SHIPPING_COST = "Shipping Cost"

    # PRICES csv
    SYM_CURVENAME = "CurveName"
    SYM_EFFECTIVEDATE = "EffectiveDate"
    SYM_FX_CURVE_CROSS_EUR_USD = "FX_curve_cross_EUR_USD"
    SYM_FX_CURVE_INPUT_USD_GBP = "FX_curve_input_USD_GBP"
    SYM_POINTDATE = "PointDate"
    SYM_POINTDATE_DESTINATION = "PointDate_Destination"
    SYM_POINTDATE_ORIGIN = "PointDate_Origin"
    SYM_POINTVALUE = "PointValue"

    # NETBACK csv
    SYM_CURVENAME_DESTINATION = 'CurveName_Destination'
    SYM_POINTVALUE_ORIGIN = 'PointValue_Origin'
    SYM_POINTVALUE_DESTINATION = 'PointValue_Destination'
    SYM_BOILOFFOUTPUT = 'BoilOffOutput'
    SYM_FUELOUTPUT = 'FuelOutput'
    SYM_CANALCOSTSOUTPUT = 'CanalCostsOutput'
    SYM_PORTCOSTSOUTPUT = 'PortCostsOutput'
    SYM_TOTALCOSTINCLUDING_REGAS_PORT = 'TotalCostIncluding(Regas&Port)'
    SYM_TOTALCOSTINCLUDING_REGAS = 'TotalCostIncluding(Regas)'
    SYM_TOTALCOSTINCLUDING_PORT = 'TotalCostIncluding(Port)'
    SYM_TOTALCOST = 'TotalCost'
    SYM_VARIABLE_SHIPPING_SINGLE = 'Variable_Shipping_Single'
    SYM_VARIABLE_SHIPPING_ROUNDTRIP = 'Variable_Shipping_Roundtrip'
    SYM_FULL_SHIPPING_ROUNTRIP = 'Full_Shipping_Rountrip'
    SYM_TOTALCOST_SUNK_SHIPING = 'TotalCost(Sunk Shiping)'

    # TERMINAL SLICES (PIVOTS)
    SYM_NETHERLANDS_GATE_JAPAN_TOKYO = 'Netherlands (Gate)-Japan (Tokyo)'
    SYM_UK_HOOK_JAPAN_TOKYO = 'UK (Hook)-Japan (Tokyo)'
    SYM_NETHERLANDS_GATE = 'Netherlands (Gate)'
    SYM_JAPAN_TOKYO = 'Japan (Tokyo)'
    SYM_UK_HOOK = 'UK (Hook)'


class RunTypeEnum(Enum):
    POOLED = 'POOLED'
    CONSECUTIVELY = 'CONSECUTIVELY'


class PivotByTerminalTypeEnum(Enum):
    VARIABLE = NetBackSymbols.SYM_VARIABLE_SHIPPING_ROUNDTRIP
    FULL = NetBackSymbols.SYM_FULL_SHIPPING_ROUNTRIP


class NetBackModel(object):
    class Mappings:
        const_arc_crv_lst = [
            'G_H_NBP.USD', 'G_H_Zeebrugge-Hub.Pnc', 'LNG_JKM_M.USD',
            'G_H_TRS.EUR', 'LNG_DES_ME_W_INDIA_M.USD',
            'LNG_H_DES_Med_MID_M.USD', 'LNG_H_DES_JKM_MID_M.USD',
            'LNG_H_DES_NWE_MID_M.USD', 'G_H_TTF.EUR', 'G_H_CEGH.EUR',
            'G_H_AOC.EUR', 'G_H_PEG-Nord.EUR', 'G_H_PSV.EUR', 'G_NYM_HH_M.USD',
            'LNG_H_DES_Lat_Am_MID_M.USD', 'FX_curve_cross_EUR.USD',
            'FX_curve_input_USD.GBP', 'FREIGHT_H_LNG_M_RolledOver.USD'
        ]

        source_file_name_variables = 'Variables.csv'
        source_file_name_costs = 'Costs.csv'

        output_file_name_netback = 'Netback'
        output_file_name_netback_narrow = 'Netback_narrow'

        day_threshold_20 = 20
        map1 = {'No': 0, 'Suez': 1, 'Panama': 1.3}
        map2 = {
            'UK (Hook)': 'EU',
            'UK (Hook)(NBP)': 'EU',
            'Belgium (Zee)': 'EU',
            'India (Dhambol)': 'ME',
            'Middle East (UAE)': 'ME',
            'China (Guandong)': 'NEA',
            'Japan (Tokyo)': 'NEA',
            "Argentina (B'Blanca)": 'LatAm',
            'France (Montoir)': 'EU',
            'Spain (Barcelona)': 'EU',
            'Spain (Barcelona)(PVB)': 'EU',
            'Italy (Rovigo)': 'EU',
            'Italy (Rovigo)(PSV)': 'EU',
            'Netherlands (Gate)': 'EU',
            'Netherlands (Gate)(TTF)': 'EU'
        }
        map3 = {
            "Argentina (B'Blanca)": 'LNG_H_DES_Lat_Am_MID_M_USD',
            'Belgium (Zee)': 'G_H_Zeebrugge-Hub_Pnc',
            'China (Guandong)': 'LNG_JKM_M_USD',
            'France (Montoir)': 'G_H_PEG-Nord_EUR',
            'India (Dhambol)': 'LNG_DES_ME_W_INDIA_M_USD',
            'Italy (Rovigo)': 'LNG_H_DES_Med_MID_M_USD',
            'Italy (Rovigo)(PSV)': 'G_H_PSV_EUR',
            'Japan (Tokyo)': 'LNG_JKM_M_USD',
            'Middle East (UAE)': 'LNG_DES_ME_W_INDIA_M_USD',
            'Netherlands (Gate)': 'LNG_H_DES_NWE_MID_M_USD',
            'Netherlands (Gate)(TTF)': 'G_H_TTF_95%_EUR',
            'Spain (Barcelona)': 'LNG_H_DES_Med_MID_M_USD',
            'Spain (Barcelona)(PVB)': 'G_H_AOC_EUR',
            'UK (Hook)': 'LNG_H_DES_NWE_MID_M_USD',
            'UK (Hook)(NBP)': 'G_H_NBP_95%_USD'
        }
        map4 = {
            'Sabine': 'G_NYM_HH_M_115%_USD',
            'Cove point': 'G_NYM_HH_M_115%_USD',
            'Nigeria': 'LNG_JKM_M_0%_USD',
            'Angola': 'LNG_JKM_M_0%_USD',
            'Qatar': 'LNG_JKM_M_0%_USD',
            'Algeria': 'LNG_JKM_M_0%_USD',
            'Yamal': 'LNG_JKM_M_0%_USD',
            'Wheatstone': 'LNG_JKM_M_0%_USD',
            'Gladstone': 'LNG_JKM_M_0%_USD',
            'T&T': 'LNG_JKM_M_0%_USD'
        }

        eur_str_filter = '_EUR'
        pnc_str_filter = '_Pnc'
        g_nym_hh_m_usd_str_filter = 'G_NYM_HH_M_USD'
        g_nym_hh_m_115_usd_str_filter = 'G_NYM_HH_M_115%_USD'
        g_h_nbp_usd_str_filter = 'G_H_NBP_USD'
        g_h_nbp_95_usd_str_filter = 'G_H_NBP_95%_USD'
        g_h_ttf_eur_str_filter = 'G_H_TTF_EUR'
        g_h_ttf_95_eur_str_filter = 'G_H_TTF_95%_EUR'
        g_h_cegh_eur_str_filter = 'G_H_CEGH_EUR'
        lng_jkm_m_0_usd_str_filter = 'LNG_JKM_M_0%_USD'
        freight_h_lng_m_rolledover_usd = 'FREIGHT_H_LNG_M_RolledOver_USD'

        var_const_24 = 24
        var_const_2 = 2
        const_3_412 = 3.412
        const_0_95 = 0.95
        const_10 = 10
        const_1_15 = 1.15
        const_0 = 0
        const_30 = 30
        const_2_00 = 2.
        const_2 = 2
        const_0_06 = 0.06
        const_0_5 = 0.5

        yamal = 'Yamal'
        panama = 'Panama'
        suez = 'Suez'

        mask_netback_narrow = [
            NetBackSymbols.SYM_EFFECTIVEDATE,
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_POINTDATE_DESTINATION,
            NetBackSymbols.SYM_REGIONFROM, NetBackSymbols.SYM_TERMINALFROM,
            NetBackSymbols.SYM_TERMINALTO, NetBackSymbols.SYM_TOTALCOST,
            NetBackSymbols.SYM_TOTALCOSTINCLUDING_REGAS_PORT,
            NetBackSymbols.SYM_TOTALCOSTINCLUDING_REGAS,
            NetBackSymbols.SYM_TOTALCOSTINCLUDING_PORT,
            NetBackSymbols.SYM_FULL_SHIPPING_ROUNTRIP,
            NetBackSymbols.SYM_VARIABLE_SHIPPING_SINGLE,
            NetBackSymbols.SYM_VARIABLE_SHIPPING_ROUNDTRIP
        ]

        format_t_long = "%Y_%m_%d_%H_%M_%S"
        format_t_short = "%Y_%m_%d"

        mask_date_type_columns = [
            NetBackSymbols.SYM_EFFECTIVEDATE,
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_POINTDATE_DESTINATION
        ]

        mask_var_full_ships_columns = [
            NetBackSymbols.SYM_EFFECTIVEDATE,
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_POINTDATE_DESTINATION,
            NetBackSymbols.SYM_TERMINALFROM, NetBackSymbols.SYM_TERMINALTO,
            NetBackSymbols.SYM_VARIABLE_SHIPPING_ROUNDTRIP,
            NetBackSymbols.SYM_FULL_SHIPPING_ROUNTRIP
        ]

    def __init__(self, start_date, end_date, root_path=None):
        # Data/cash adaptors
        from gmt.fom.gas.shared.models.net_back.data.adapter import DataAdaptor
        self.data_adaptor = DataAdaptor(root_path, end_date)

        # Source data
        self.src_variables = None
        self.src_costs = None

        # Time dimension
        self.start_date = start_date
        self.end_date = end_date
        self.t_range = None
        self.from_to_dates_dct = None

        # Formatted source dataFrames
        self.variables = None

        # Pet time tick
        self._arc_curves = None
        self.prices = None
        self.vars_ts = None

        # Output dataFrames
        self.netback = None
        self.netback_narrow = None

        # Pivots
        self.pivot_var_ship = None
        self.pivot_full_ship = None

        # t-range
        self.mk_t_range()

    @classmethod
    def get_cached_days(cls):
        data_adaptor = DataAdaptor()  # MongoDB
        return data_adaptor.cached_t_range

    def load_data(self):
        self.src_variables = self.data_adaptor.load_variables()
        self.src_costs = self.data_adaptor.load_costs()

    def mk_t_range(self):
        t1 = self.start_date
        t2 = self.end_date
        res = []
        for n in range(int((t2 - t1).days) + 1):
            t = t1 + timedelta(n)
            if t.isoweekday() not in [6, 7]:
                res.append(t)
        self.t_range = sorted(res)

    def mk_from_to_dct(self):
        # This dictionary provides time-brackets for the subsequent arc-curves retrieval
        def _get_from_to_dates(t: date):
            if t.day > NetBackModel.Mappings.day_threshold_20:
                from_date = t + pd.DateOffset(months=2)
                to_date = t + pd.DateOffset(months=2, years=2)
            else:
                from_date = t + pd.DateOffset(months=1)
                to_date = t + pd.DateOffset(months=1, years=2)
            return dict(
                zip(['from_date', 'to_date'],
                    [from_date.date(), to_date.date()]))

        self.from_to_dates_dct = {
            t: _get_from_to_dates(t)
            for t in self.t_range
        }

    def mk_variables_df(self):
        def f1(df, costs_df):
            df[NetBackSymbols.SYM_DAYS_TRAVEL_TEMP] = \
                df[NetBackSymbols.SYM_DISTANCES] / (
                        costs_df[NetBackSymbols.SYM_LADEN_SPEED_KNOTS].iloc[0] * NetBackModel.Mappings.var_const_24)
            return df

        def f2(df):
            conditions = [
                df[NetBackSymbols.SYM_CANAL_FEE] == k
                for k in NetBackModel.Mappings.map1.keys()
            ]
            choices = NetBackModel.Mappings.map1.values()
            df[NetBackSymbols.SYM_ADD_DAYS] = pd.Series(
                np.select(conditions, choices, default=9999999),
                name=NetBackSymbols.SYM_ADD_DAYS)
            return df

        def f3(df):
            df[NetBackSymbols.SYM_DAYS_TRAVEL_ONE_WAY_INC_TRANSIT] = df[NetBackSymbols.SYM_DAYS_TRAVEL_TEMP] + \
                                                                     df[NetBackSymbols.SYM_ADD_DAYS]
            return df

        def f4(df, costs_df):
            df[NetBackSymbols.SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT] = \
                + df[NetBackSymbols.SYM_DAYS_TRAVEL_ONE_WAY_INC_TRANSIT] * NetBackModel.Mappings.var_const_2 \
                + costs_df[NetBackSymbols.SYM_ONEWAY_PORT_TURNAROUND_TIME_LOAD_DISCHARGE_DAYS].iloc[0]
            return df

        def f5(df, costs_df):
            df[NetBackSymbols.SYM_BOIL_OFF] = costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0] \
                                              * costs_df[NetBackSymbols.SYM_LADEN_NATURAL_BOIL_OFF_GAS_DAY].iloc[0] \
                                              * df[NetBackSymbols.SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT]

            return df

        def f6(df, costs_df):
            df[NetBackSymbols.SYM_DELIVERED_VOLUME] = costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0] \
                                                      - df[NetBackSymbols.SYM_BOIL_OFF]

            return df

        def f7(df):
            conditions = [
                df[NetBackSymbols.SYM_TERMINALTO] == k
                for k in NetBackModel.Mappings.map2.keys()
            ]
            choices = NetBackModel.Mappings.map2.values()
            df[NetBackSymbols.SYM_REGIONCODE] = pd.Series(
                np.select(conditions, choices, default=9999999),
                name=NetBackSymbols.SYM_REGIONCODE)
            return df

        def f8(df):
            conditions = [
                df[NetBackSymbols.SYM_TERMINALTO] == k
                for k in NetBackModel.Mappings.map3.keys()
            ]
            choices = NetBackModel.Mappings.map3.values()
            df[NetBackSymbols.SYM_CURVENAME] = pd.Series(
                np.select(conditions, choices, default=9999999),
                name=NetBackSymbols.SYM_REGIONCODE)
            return df

        def f9(df):
            conditions = [
                df[NetBackSymbols.SYM_TERMINALFROM] == k
                for k in NetBackModel.Mappings.map4.keys()
            ]
            choices = NetBackModel.Mappings.map4.values()
            df[NetBackSymbols.SYM_ORIGINPRICECURVE] = pd.Series(
                np.select(conditions, choices, default=9999999),
                name=NetBackSymbols.SYM_REGIONCODE)
            return df

        # apply composition of functions: (g * f)(x) := f( g(x) ) <--note the order of the functions
        F = Utils.compose(f9, f8, f7, partial(f6, costs_df=self.src_costs),
                          partial(f5, costs_df=self.src_costs),
                          partial(f4, costs_df=self.src_costs), f3, f2,
                          partial(f1, costs_df=self.src_costs))

        self.variables = F(self.src_variables.copy(deep=True))

    def _get_arc_curves(self, t: date, env='prod'):
        def _get_one_arc_curve(curve, _t, _from_date,
                               _to_date) -> pd.DataFrame:

            try:
                data_adaptor = DataAdapterFactory.create("arc", env=env)
                curve_df = data_adaptor.get_forward_curve(
                    curve, _t).resample('M').mean().loc[_from_date:_to_date]
                curve_df.index = [
                    date(t.year, t.month, 1) for t in curve_df.index
                ]
                curve_df = curve_df.to_frame()
                curve_df.reset_index(inplace=True)
                curve_df.columns = [
                    NetBackSymbols.SYM_POINTDATE, NetBackSymbols.SYM_POINTVALUE
                ]
                curve_df[NetBackSymbols.SYM_CURVENAME] = curve
                return curve_df
            except Exception as e:
                logger.info(e.args[0])
                logger.info(
                    f'Issue with arc retrieval for curve={curve}, effective date={_t}'
                )
                return pd.DataFrame()

        arc_curves = self.Mappings.const_arc_crv_lst
        t_start = datetime.now()

        from_date = self.from_to_dates_dct[t]['from_date']
        to_date = self.from_to_dates_dct[t]['to_date']
        arc_curves_df = pd.concat([
            _get_one_arc_curve(curve, t, from_date, to_date)
            for curve in arc_curves
        ],
            axis=0,
            sort=False)
        t_end = datetime.now()
        logger.info(
            f'Took {(t_end - t_start).seconds} seconds to retrieve data from arc.'
        )
        self._arc_curves = arc_curves_df[[
            NetBackSymbols.SYM_CURVENAME, NetBackSymbols.SYM_POINTDATE,
            NetBackSymbols.SYM_POINTVALUE
        ]]

    def _format_arc_curves(self, t):
        arc_crvs_df = self._arc_curves
        arc_crvs_df[NetBackSymbols.SYM_CURVENAME] = arc_crvs_df[
            NetBackSymbols.SYM_CURVENAME].str.replace('.', '_')
        arc_crvs_df[NetBackSymbols.SYM_POINTDATE_ORIGIN] = pd.to_datetime(
            arc_crvs_df[NetBackSymbols.SYM_POINTDATE])
        arc_crvs_df[NetBackSymbols.SYM_EFFECTIVEDATE] = pd.to_datetime(t)
        arc_crvs_df[NetBackSymbols.SYM_POINTDATE_DESTINATION] = arc_crvs_df[
            NetBackSymbols.SYM_POINTDATE_ORIGIN]
        mask = [
            NetBackSymbols.SYM_CURVENAME, NetBackSymbols.SYM_POINTVALUE,
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_EFFECTIVEDATE,
            NetBackSymbols.SYM_POINTDATE_DESTINATION
        ]
        self._arc_curves = arc_crvs_df[mask]

    def _transform_arc_curves(self):
        def f1(df):
            mask = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackSymbols.SYM_FX_CURVE_CROSS_EUR_USD
            mapping = df[mask].set_index(NetBackSymbols.SYM_POINTDATE_ORIGIN)[
                NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_FX_CURVE_CROSS_EUR_USD] = df[
                NetBackSymbols.SYM_POINTDATE_ORIGIN].map(mapping)
            df[NetBackSymbols.SYM_FX_CURVE_CROSS_EUR_USD] = df[
                NetBackSymbols.SYM_FX_CURVE_CROSS_EUR_USD].fillna(
                method='ffill')
            return df

        def f2(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.eur_str_filter, case=False)
            x = df[NetBackSymbols.SYM_POINTVALUE].apply(pd.to_numeric, downcast='float') \
                / df[NetBackSymbols.SYM_FX_CURVE_CROSS_EUR_USD].apply(
                pd.to_numeric, downcast='float') / NetBackModel.Mappings.const_3_412 * NetBackModel.Mappings.const_0_95
            y = df[NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f3(df):
            mask = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackSymbols.SYM_FX_CURVE_INPUT_USD_GBP
            mapping = df[mask].set_index(NetBackSymbols.SYM_POINTDATE_ORIGIN)[
                NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_FX_CURVE_INPUT_USD_GBP] = df[
                NetBackSymbols.SYM_POINTDATE_ORIGIN].map(mapping)
            df[NetBackSymbols.SYM_FX_CURVE_INPUT_USD_GBP] = df[
                NetBackSymbols.SYM_FX_CURVE_INPUT_USD_GBP].fillna(
                method='ffill')
            return df

        def f4(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.pnc_str_filter, case=False)
            x = df[NetBackSymbols.SYM_POINTVALUE].apply(pd.to_numeric, downcast='float') \
                / df[NetBackSymbols.SYM_FX_CURVE_INPUT_USD_GBP].apply(pd.to_numeric,
                                                                      downcast='float') / NetBackModel.Mappings.const_10
            y = df[NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f5(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.g_nym_hh_m_usd_str_filter, case=False)
            x = df['PointValue'].apply(
                pd.to_numeric,
                downcast='float') * NetBackModel.Mappings.const_1_15
            y = df['PointValue']
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f6(df):
            cond = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackModel.Mappings.g_nym_hh_m_usd_str_filter
            x = NetBackModel.Mappings.g_nym_hh_m_115_usd_str_filter
            y = df[NetBackSymbols.SYM_CURVENAME]
            df[NetBackSymbols.SYM_CURVENAME] = np.where(cond, x, y)
            return df

        def f7(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.g_h_nbp_usd_str_filter, case=False)
            x = df[NetBackSymbols.SYM_POINTVALUE].apply(
                pd.to_numeric,
                downcast='float') * NetBackModel.Mappings.const_0_95
            y = df[NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f8(df):
            cond = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackModel.Mappings.g_h_nbp_usd_str_filter
            x = NetBackModel.Mappings.g_h_nbp_95_usd_str_filter
            y = df[NetBackSymbols.SYM_CURVENAME]
            df[NetBackSymbols.SYM_CURVENAME] = np.where(cond, x, y)
            return df

        def f9(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.g_h_ttf_eur_str_filter, case=False)
            x = df[NetBackSymbols.SYM_POINTVALUE].apply(
                pd.to_numeric,
                downcast='float') * NetBackModel.Mappings.const_0_95
            y = df[NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f10(df):
            cond = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackModel.Mappings.g_h_ttf_eur_str_filter
            x = NetBackModel.Mappings.g_h_ttf_95_eur_str_filter
            y = df[NetBackSymbols.SYM_CURVENAME]
            df[NetBackSymbols.SYM_CURVENAME] = np.where(cond, x, y)
            return df

        def f11(df):
            cond = df[NetBackSymbols.SYM_CURVENAME].str.contains(
                NetBackModel.Mappings.g_h_cegh_eur_str_filter, case=False)
            x = df[NetBackSymbols.SYM_POINTVALUE].apply(
                pd.to_numeric,
                downcast='float') * NetBackModel.Mappings.const_0
            y = df[NetBackSymbols.SYM_POINTVALUE]
            df[NetBackSymbols.SYM_POINTVALUE] = np.where(cond, x, y)
            return df

        def f12(df):
            cond = df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackModel.Mappings.g_h_cegh_eur_str_filter
            x = NetBackModel.Mappings.lng_jkm_m_0_usd_str_filter
            y = df[NetBackSymbols.SYM_CURVENAME]
            df[NetBackSymbols.SYM_CURVENAME] = np.where(cond, x, y)
            return df

        df = self._arc_curves
        F = Utils.compose(f12, f11, f10, f9, f8, f7, f6, f5, f4, f3, f2, f1)
        self.prices = F(df)

    def mk_prices_df(self, t):
        self._get_arc_curves(t)
        self._format_arc_curves(t)
        self._transform_arc_curves()

    def _create_vars_ts_df(self, t):
        vars_ts = self.variables.copy(deep=True)
        n = vars_ts.shape[0]
        t_range = pd.date_range(start=t, freq='MS', periods=12, name='Dates')

        # Make a len(t_range) copies of variables df
        vars_ts = pd.concat([vars_ts for t in range(len(t_range))], axis=0)
        t_col = [[t] * n for t in t_range]
        flat_t_col = [item for sublist in t_col for item in sublist]
        # Insert column
        vars_ts.insert(0, NetBackSymbols.SYM_POINTDATE_ORIGIN, flat_t_col)
        self.vars_ts = vars_ts

    def _transform_vars_ts_df(self):
        def f1(df, prices_df):
            mask = prices_df[
                       NetBackSymbols.
                           SYM_CURVENAME] == NetBackModel.Mappings.freight_h_lng_m_rolledover_usd
            mapping = prices_df[mask].set_index(
                NetBackSymbols.SYM_POINTDATE_ORIGIN)[
                NetBackSymbols.SYM_POINTVALUE]

            cond = df[
                       NetBackSymbols.
                           SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT] > NetBackModel.Mappings.const_30

            x = ((df[NetBackSymbols.SYM_POINTDATE_ORIGIN] + pd.DateOffset(months=1)).map(mapping) \
                 + df[NetBackSymbols.SYM_POINTDATE_ORIGIN].map(mapping)) / NetBackModel.Mappings.const_2_00

            y = df[NetBackSymbols.SYM_POINTDATE_ORIGIN].map(mapping)
            df[NetBackSymbols.SYM_SHIPPING_COST] = np.where(cond, x, y)

            return df

        def f2(df):
            mask = [
                NetBackSymbols.SYM_REGAS_COSTS,
                NetBackSymbols.SYM_PORT_CHARGES, NetBackSymbols.SYM_BOIL_OFF,
                NetBackSymbols.SYM_DELIVERED_VOLUME,
                NetBackSymbols.SYM_SHIPPING_COST
            ]
            df[mask] = df[mask].apply(pd.to_numeric, downcast='float')
            return df

        def f3(df, costs_df):
            df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] = (
                    df[NetBackSymbols.SYM_SHIPPING_COST] *
                    df[NetBackSymbols.SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT] /
                    costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0])

            return df

        F = Utils.compose(partial(f3, costs_df=self.src_costs), f2,
                          partial(f1, prices_df=self.prices))

        self.vars_ts = F(self.vars_ts)

    def mk_vars_ts_df(self, t):
        self._create_vars_ts_df(t)
        self._transform_vars_ts_df()

    def _create_netback_df(self):
        mask = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN, NetBackSymbols.SYM_CURVENAME,
            NetBackSymbols.SYM_EFFECTIVEDATE
        ]
        mask_on = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN, NetBackSymbols.SYM_CURVENAME
        ]
        netback = self.vars_ts.merge(self.prices[mask],
                                     how='inner',
                                     on=mask_on)

        mask = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN, NetBackSymbols.SYM_CURVENAME,
            NetBackSymbols.SYM_POINTVALUE
        ]
        mask_right_on = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN, NetBackSymbols.SYM_CURVENAME
        ]
        mask_left_on = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_ORIGINPRICECURVE
        ]
        left_suffix = '_from_netback'
        right_suffix = '_from_prices'
        netback = netback.merge(self.prices[mask],
                                how='inner',
                                right_on=mask_right_on,
                                left_on=mask_left_on,
                                suffixes=(left_suffix, right_suffix))
        netback = netback.drop(
            columns=[f'{NetBackSymbols.SYM_CURVENAME}{right_suffix}'])

        netback.rename(columns={
            f'{NetBackSymbols.SYM_CURVENAME}{left_suffix}':
                NetBackSymbols.SYM_CURVENAME_DESTINATION,
            NetBackSymbols.SYM_POINTVALUE:
                NetBackSymbols.SYM_POINTVALUE_ORIGIN
        },
            inplace=True)

        return netback

    def _transform_netback_df(self, netback):
        def f1(df):
            df[NetBackSymbols.SYM_POINTDATE_DESTINATION] = df[
                NetBackSymbols.SYM_POINTDATE_ORIGIN]
            return df

        def f2(df):
            cond = df[
                       NetBackSymbols.
                           SYM_DAYS_TRAVEL_RETURN_INC_TIME_AT_PORT] > NetBackModel.Mappings.const_30
            x = df[NetBackSymbols.SYM_POINTDATE_DESTINATION] + pd.DateOffset(
                months=1)
            y = df[NetBackSymbols.SYM_POINTDATE_DESTINATION]
            df[NetBackSymbols.SYM_POINTDATE_DESTINATION] = np.where(cond, x, y)
            return df

        def f3(df, prices_df):
            mask = [
                NetBackSymbols.SYM_POINTDATE_DESTINATION,
                NetBackSymbols.SYM_CURVENAME, NetBackSymbols.SYM_POINTVALUE
            ]
            mask_right_on = [
                NetBackSymbols.SYM_POINTDATE_DESTINATION,
                NetBackSymbols.SYM_CURVENAME
            ]
            mask_left_on = [
                NetBackSymbols.SYM_POINTDATE_DESTINATION,
                NetBackSymbols.SYM_CURVENAME_DESTINATION
            ]

            df = df.merge(prices_df[mask],
                          right_on=mask_right_on,
                          left_on=mask_left_on)
            return df

        def f4(df):
            df.rename(columns={
                NetBackSymbols.SYM_POINTVALUE:
                    NetBackSymbols.SYM_POINTVALUE_DESTINATION
            },
                inplace=True)
            return df

        def f5(df):
            df = df.drop(columns=[NetBackSymbols.SYM_CURVENAME])
            return df

        def f6(df):
            mask = [
                NetBackSymbols.SYM_BOIL_OFF,
                NetBackSymbols.SYM_POINTVALUE_DESTINATION,
                NetBackSymbols.SYM_POINTVALUE_ORIGIN
            ]
            df[mask] = df[mask].apply(pd.to_numeric, downcast='float')
            return df

        def f7(df, costs_df):
            df[NetBackSymbols.SYM_BOILOFFOUTPUT] = (
                                                           df[NetBackSymbols.SYM_POINTVALUE_DESTINATION] *
                                                           df[NetBackSymbols.SYM_BOIL_OFF]
                                                   ) / costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0]
            return df

        def f8(df, costs_df):
            cond = df[
                       NetBackSymbols.SYM_TERMINALFROM] == NetBackModel.Mappings.yamal

            a = costs_df[
                NetBackSymbols.
                    SYM_ONEWAY_PORT_TURNAROUND_TIME_LOAD_DISCHARGE_DAYS].iloc[0]
            b = costs_df[
                NetBackSymbols.SYM_FUEL_CONSUMPTION_IN_PORT_TONNES_DAY].iloc[0]
            c = costs_df[NetBackSymbols.SYM_USD_TONNE_HFO].iloc[0]
            e = costs_df[
                NetBackSymbols.SYM_FUEL_OIL_CONSUMPTION_TONNES_DAY].iloc[0]
            f = NetBackModel.Mappings.const_2
            g = df[NetBackSymbols.SYM_DAYS_TRAVEL_ONE_WAY_INC_TRANSIT]
            h = costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0]

            x = ((a * b * c) + (c * e * f * g)) / h
            y = NetBackModel.Mappings.const_0_06
            df[NetBackSymbols.SYM_FUELOUTPUT] = np.where(cond, x, y)
            return df

        def f9(df, costs_df):
            cond1 = df[
                        NetBackSymbols.SYM_CANAL_FEE] == NetBackModel.Mappings.panama
            a = costs_df[NetBackSymbols.SYM_PANAMA_TOTAL].iloc[0]
            b = costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0]

            cond2 = df[
                        NetBackSymbols.SYM_CANAL_FEE] == NetBackModel.Mappings.suez
            c = costs_df[NetBackSymbols.SYM_SUEZ_TOTAL].iloc[0]
            d = costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0]

            df[NetBackSymbols.SYM_CANALCOSTSOUTPUT] = np.where(
                cond1, (a / b),
                np.where(cond2, (c / d), NetBackModel.Mappings.const_0))

            return df

        def f10(df, costs_df):
            df[NetBackSymbols.SYM_PORTCOSTSOUTPUT] = df[NetBackSymbols.SYM_PORT_CHARGES] / \
                                                     costs_df[NetBackSymbols.SYM_LOADED_GAS_CARGO_MMBTU].iloc[0]
            return df

        def f11(df):
            df[NetBackSymbols.SYM_TOTALCOSTINCLUDING_REGAS_PORT] = (
                    df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] +
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] +
                    df[NetBackSymbols.SYM_FUELOUTPUT] +
                    df[NetBackSymbols.SYM_CANALCOSTSOUTPUT] +
                    df[NetBackSymbols.SYM_PORTCOSTSOUTPUT] +
                    df[NetBackSymbols.SYM_REGAS_COSTS])
            return df

        def f12(df):
            df[NetBackSymbols.SYM_TOTALCOSTINCLUDING_REGAS] = (
                    df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] +
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] +
                    df[NetBackSymbols.SYM_FUELOUTPUT] +
                    df[NetBackSymbols.SYM_CANALCOSTSOUTPUT] +
                    df[NetBackSymbols.SYM_REGAS_COSTS])
            return df

        def f13(df):
            df[NetBackSymbols.SYM_TOTALCOSTINCLUDING_PORT] = (
                    df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] +
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] +
                    df[NetBackSymbols.SYM_FUELOUTPUT] +
                    df[NetBackSymbols.SYM_CANALCOSTSOUTPUT] +
                    df[NetBackSymbols.SYM_PORTCOSTSOUTPUT])
            return df

        def f14(df):
            df[NetBackSymbols.SYM_TOTALCOST] = (
                    df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] +
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] +
                    df[NetBackSymbols.SYM_FUELOUTPUT] +
                    df[NetBackSymbols.SYM_CANALCOSTSOUTPUT])
            return df

        def f15(df):
            df[NetBackSymbols.SYM_TOTALCOST_SUNK_SHIPING] = (
                    df[NetBackSymbols.SYM_SHIPPINGCOSTOUTPUT] +
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] +
                    df[NetBackSymbols.SYM_FUELOUTPUT] +
                    df[NetBackSymbols.SYM_CANALCOSTSOUTPUT])
            return df

        def f16(df):
            df[NetBackSymbols.SYM_VARIABLE_SHIPPING_ROUNDTRIP] = (
                    df[NetBackSymbols.SYM_POINTVALUE_DESTINATION] -
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] -
                    df[NetBackSymbols.SYM_FUELOUTPUT] -
                    df[NetBackSymbols.SYM_PORTCOSTSOUTPUT] -
                    df[NetBackSymbols.SYM_POINTVALUE_ORIGIN])
            return df

        def f17(df):
            df[NetBackSymbols.SYM_VARIABLE_SHIPPING_SINGLE] = (
                    df[NetBackSymbols.SYM_POINTVALUE_DESTINATION] -
                    NetBackModel.Mappings.const_0_5 *
                    df[NetBackSymbols.SYM_BOILOFFOUTPUT] -
                    df[NetBackSymbols.SYM_FUELOUTPUT] -
                    df[NetBackSymbols.SYM_PORTCOSTSOUTPUT] -
                    df[NetBackSymbols.SYM_POINTVALUE_ORIGIN])
            return df

        def f18(df):
            df[NetBackSymbols.SYM_FULL_SHIPPING_ROUNTRIP] = (
                    df[NetBackSymbols.SYM_POINTVALUE_DESTINATION] -
                    df[NetBackSymbols.SYM_TOTALCOSTINCLUDING_PORT] -
                    df[NetBackSymbols.SYM_POINTVALUE_ORIGIN])
            return df

        F = Utils.compose(f18, f17, f16, f15, f14, f13, f12, f11,
                          partial(f10, costs_df=self.src_costs),
                          partial(f9, costs_df=self.src_costs),
                          partial(f8, costs_df=self.src_costs),
                          partial(f7, costs_df=self.src_costs), f6, f5, f4,
                          partial(f3, prices_df=self.prices), f2, f1)
        netback = F(netback)
        return netback

    def mk_netback(self):
        netback = self._create_netback_df()
        netback = self._transform_netback_df(netback)
        return netback

    def fit(self):
        logger.info('Fitting')
        self.load_data()
        self.mk_from_to_dct()
        self.mk_variables_df()

    def one_tick_forecast(self, t, output=False):
        logger.info(f'Working t={t}')
        self.mk_prices_df(t)
        self.mk_vars_ts_df(t)
        netback = self.mk_netback()
        if output:
            return netback
        else:
            self.data_adaptor.persist(netback, t)

    def forecast_consecutively(self):
        logger.debug('forecast consecutively')
        for t in sorted(self.t_range):
            self.one_tick_forecast(t)

    def forecast_pooled(self, num_processes=None):
        if num_processes is None:
            num_processes = mp.cpu_count()
        pool = Pool(processes=num_processes)
        netbacks = []
        for t in sorted(self.t_range):
            netbacks.append(
                pool.apply_async(NetBackModel.one_tick_forecast,
                                 args=(self, t)))

        pool.close()
        pool.join()
        _ = [r.get() for r in netbacks]

    def forecast_factory(self, run_type):
        if run_type.value == RunTypeEnum.CONSECUTIVELY.value:
            self.forecast_consecutively()
        elif run_type.value == RunTypeEnum.POOLED.value:
            self.forecast_pooled()
        else:
            raise NotImplementedError(f'Type={run_type} not implemented!')

    def forecast(self,
                 run_type: RunTypeEnum = RunTypeEnum.POOLED,
                 use_cache=True):
        logger.info('Forecasting')
        if use_cache:
            not_cached_ticks = sorted(
                list(
                    set(self.t_range).difference(
                        self.data_adaptor.cached_t_range)))
            if len(not_cached_ticks) == 0:
                logger.info("All days are cached")
            else:
                logger.debug(f'Days not in cache: {not_cached_ticks}')
                self.t_range = list(set(not_cached_ticks))
                logger.debug('forecast consecutively')
                for t in sorted(self.t_range):
                    self.one_tick_forecast(t)
        else:
            NetBackModel.forecast_factory(self, run_type)

    @classmethod
    def retrieve(cls, t_range=None, query=None, root_path=None):
        logger.info(f'Retrieving...')
        data_adaptor = DataAdaptor(root_path)
        return data_adaptor.load_cache(t_range, query)


    @classmethod
    def pivot_by_terminal(cls, netback, save_path=None):
        def f1(df):
            df = df.set_index([
                NetBackSymbols.SYM_TERMINALFROM, NetBackSymbols.SYM_TERMINALTO
            ]).sort_index()
            return df

        def f2(df, pivot_type_enum: PivotByTerminalTypeEnum):
            df = df.pivot_table(pivot_type_enum.value, [
                NetBackSymbols.SYM_TERMINALFROM,
                NetBackSymbols.SYM_POINTDATE_DESTINATION,
                NetBackSymbols.SYM_EFFECTIVEDATE
            ], NetBackSymbols.SYM_TERMINALTO)
            return df

        def f3(df):
            df.dropna(inplace=True)
            return df

        def f4(df):
            df[NetBackSymbols.SYM_NETHERLANDS_GATE_JAPAN_TOKYO] = df[
                                                                      NetBackSymbols.SYM_NETHERLANDS_GATE] - df[
                                                                      NetBackSymbols.SYM_JAPAN_TOKYO]
            return df

        def f5(df):
            df[NetBackSymbols.
                SYM_UK_HOOK_JAPAN_TOKYO] = df[NetBackSymbols.SYM_UK_HOOK] - df[
                NetBackSymbols.SYM_JAPAN_TOKYO]

            return df

        Pivot_variable_func = Utils.compose(
            f5,
            f4,
            f3,
            partial(f2, pivot_type_enum=PivotByTerminalTypeEnum.VARIABLE),
            f1)
        Pivot_full_func = Utils.compose(
            f5,
            f4,
            f3, partial(f2, pivot_type_enum=PivotByTerminalTypeEnum.FULL), f1)

        df = netback[NetBackModel.Mappings.mask_var_full_ships_columns]
        pivot_var_ship = Pivot_variable_func(df.copy(deep=True))
        pivot_full_ship = Pivot_full_func(df.copy(deep=True))

        df = pivot_var_ship
        pivot_var_dict = {f'{terminal}_Pivot_VarShip': df.loc[terminal].reset_index()
                          for terminal in df.reset_index()[NetBackSymbols.SYM_TERMINALFROM].unique()}

        df = pivot_full_ship

        pivot_full_dict = {f'{terminal}_Pivot_FullShip': df.loc[terminal].reset_index()
                           for terminal in df.reset_index()[NetBackSymbols.SYM_TERMINALFROM].unique()}

        netback_narrow = netback[NetBackModel.Mappings.mask_netback_narrow]

        if save_path:
            netback.to_csv(os.path.join(save_path, NetBackModel.Mappings.output_file_name_netback + '.csv'),
                           index=False)
            netback_narrow.to_csv(
                os.path.join(save_path, NetBackModel.Mappings.output_file_name_netback_narrow + '.csv'),
                index=False)

            for terminal, df in pivot_var_dict.items():
                df.to_csv(os.path.join(save_path, terminal + '.csv'), index=False)

            for terminal, df in pivot_full_dict.items():
                df.to_csv(os.path.join(save_path, terminal + '.csv'), index=False)
        else:
            return netback_narrow, pivot_var_dict, pivot_full_dict
