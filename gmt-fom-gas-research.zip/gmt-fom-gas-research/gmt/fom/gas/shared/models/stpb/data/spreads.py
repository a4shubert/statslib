import logging

import numpy as np
import pandas as pd

logger = logging.getLogger(__file__)
from gmt.fom.gas.shared.utils.dframe import to_pd_todatetime


def get_actuals_clean_dark_spreads_from_file():
    def _get(path):
        df = pd.read_csv(path, header=None)
        columns = ['curve_name', 'point_date', 'value']
        df.columns = columns
        df = to_pd_todatetime(df, 'point_date', utc=False)
        df.index = pd.DatetimeIndex(df.set_index('point_date').index)
        df.index.name = 'day'
        df = df.resample('1D').sum()
        return df

    def _transform(spreads):
        logger.info('Transforming spreads...')
        spreads = spreads.reset_index()
        spreads.columns = ['day', 'clean_spreads']
        spreads.set_index('day', inplace=True)
        null_idx = spreads[(spreads == 0).any(axis=1)].index
        spreads.loc[null_idx] = np.NaN
        spreads = spreads.fillna(method='ffill')
        spreads.index = pd.DatetimeIndex(spreads.index)
        return spreads.squeeze()

    logger.info('Getting spreads from csv...')
    path = r"\\trading1\Common\gasmodels\short_term_power_burn\data\UK\covariates\Prices\clean_spread_eur_actuals.csv"
    clean_spreads = _get(path)

    path = r"\\trading1\Common\gasmodels\short_term_power_burn\data\UK\covariates\Prices\dark_spread_eur_actuals.csv"
    dark_spreads = _get(path)

    return _transform(clean_spreads).rename('clean_spreads'), \
           _transform(dark_spreads).rename('dark_spreads')


# TODO:TEMPORARY FUNCTION
def get_forecast_clean_dark_spreads(horizon):
    clean_spreads, dark_spreads = get_actuals_clean_dark_spreads_from_file()
    return clean_spreads, dark_spreads
