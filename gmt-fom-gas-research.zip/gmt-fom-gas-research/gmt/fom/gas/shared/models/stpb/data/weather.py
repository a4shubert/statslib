import logging

import pandas as pd

from gmt.fom.gas.shared import statslib as stb

logger = logging.getLogger(__file__)


def get_actuals_temp_precip_wind_from_file():
    def _get():
        path = r'\\trading1\Common\gasmodels\short_term_power_burn\data\UK\covariates\Weather'
        myData = stb.SmartData()
        myData.acquire.from_folder(path)
        lst = []
        logging.info('Retrieving weather from csv...')
        for name in myData.sourced.names:
            df = myData.sourced.get(name)
            df.columns = [s.replace('\r\n', '_').replace(' ', '_').replace('(', '').replace(')', '').replace('/', '_')
                              .replace('°', '_grad_').replace('__', '_').replace('europe_uk_', '').lower() for s in
                          df.columns]
            lst.append(df.columns.tolist())
            df = stb.utils.dframe.to_pd_todatetime(df, 'area_country_city_gas_day')

        weather = pd.DataFrame()
        t = 0
        for name in myData.sourced.names:
            df = myData.sourced.get(name)
            t += df.shape[0]
            weather = pd.concat([weather, df], axis=0, sort=True)
        weather.set_index('area_country_city_gas_day', inplace=True)
        weather.index.name = 'day'
        weather.index = pd.DatetimeIndex(weather.index)
        return weather

    def _transform(weather):
        logging.info('Transforming weather...')
        end = weather.index.max()
        start = end - pd.DateOffset(years=5)
        dt_range_len = len(pd.date_range(start=start, end=end))

        cols = weather.columns

        res = []
        for col in cols:
            _df = weather[col].dropna()
            res.append([col, _df.shape[0], max(0, dt_range_len - _df.shape[0]), _df.index.min(), _df.index.max()])

        summary = pd.DataFrame(res)
        summary.columns = ['name', 'count', 'missing', 'min', 'max']
        summary.sort_values(by=['count'], inplace=True, ascending=False)
        weather_filtered = summary.where(summary.missing < 31).dropna()['name'].values
        avg_weather = weather[weather_filtered].dropna(axis=0).resample('D').mean().mean(axis=1)
        avg_weather_d = avg_weather.resample('D').mean()
        avg_weather_dfill = pd.concat([avg_weather_d.ffill(), avg_weather_d.bfill()]).groupby(level=0).mean()
        return avg_weather_dfill

    # retrieve weather df and split into temp precip and wind
    weather = _get()
    f_temp = filter(lambda col: 'temperature' in col, weather.columns)
    f_precip = filter(lambda col: 'precipitation' in col, weather.columns)
    f_wind = filter(lambda col: 'wind' in col, weather.columns)
    temp, precip, wind = weather[f_temp], weather[f_precip], weather[f_wind]

    # take average across towns and use mean fill #NA: average of ffill and bfill
    return _transform(temp).rename('temperature'), \
           _transform(precip).rename('precip'), \
           _transform(wind).rename('wind')


def get_forecast_temp_precip_wind(horizon):
    temp, precip, wind = get_actuals_temp_precip_wind_from_file()
    return temp, precip, wind
