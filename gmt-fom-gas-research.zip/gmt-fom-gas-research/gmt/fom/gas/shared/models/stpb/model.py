import logging
import os
from datetime import date

import pandas as pd
import statsmodels.api as sm

import gmt.fom.gas.shared.statslib as stb
from gmt.fom.gas.shared.models.stpb.data.adapter import DataAdapter

logger = logging.getLogger(__file__)
file_folder = os.path.dirname(__file__)
fitted_folder = os.path.abspath(os.path.join(file_folder, 'calibrator'))


class ShortTermPowerBurnModel(object):
    COVARIATES = [
        'const',
        'dark_spreads',
        'precip',
        'temperature',
        'wind', ]

    DEPENDENT = ['ccgt']

    SARIMAX_SPECIFICATION_DICT = dict(order=(1, 1, 1),
                                      trend='n',
                                      enforce_stationarity=True,
                                      seasonal_order=(1, 0, 1, 7))

    CALIBRATION_DAYS_COUNT = int(3.0 * 365.25)

    def __init__(self, asof=None, recalibrate=False):
        self.asof = pd.to_datetime(asof)
        self.run_day = date.today()
        self.recalibrate = recalibrate
        self.data_adapter = DataAdapter()
        self.calibrator = None
        self.fitted = None
        self.fitted_vals = None
        self.params = None
        self.forecast_vals = None
        # design matrix for calibration
        self.dm = None
        # design matrix for forecast
        self.dm_forecast = None

    def _get_calib_dm(self):
        logger.info('Building calibration design matrix...')
        ccgt = self.data_adapter.get_ccgt()
        temp, precip, wind = self.data_adapter.get_temp_precip_wind()
        clean_spreads, dark_spreads = self.data_adapter.get_spreads()
        # calibration design matrix:
        dm = pd.concat([ccgt, dark_spreads, temp, precip, wind], axis=1)
        dm['const'] = 1.0
        dm = dm[self.DEPENDENT + self.COVARIATES]
        dm = dm.dropna(axis=0).sort_index(ascending=False).resample('D').mean()
        na_idx = stb.utils.dframe.df_see_null_na_values(dm, silent=True)
        assert len(na_idx) == 0
        start_day = self.asof - pd.DateOffset(days=self.CALIBRATION_DAYS_COUNT - 1)
        dm = dm.loc[start_day:].iloc[:self.CALIBRATION_DAYS_COUNT]
        assert dm.shape[0] == self.CALIBRATION_DAYS_COUNT
        return dm

    def fit(self):
        self.dm = self._get_calib_dm()
        if self.recalibrate:
            logger.info('Fitting...')
            self.calibrator = sm.tsa.statespace.SARIMAX(
                endog=self.dm[self.DEPENDENT],
                exog=self.dm[self.COVARIATES],
                **self.SARIMAX_SPECIFICATION_DICT)
            self.fitted = self.calibrator.fit()
            self.fitted.save(fname=os.path.join(fitted_folder, 'fitted.sarimax'))
        logger.info('Loading calibrated model...')
        self.fitted = sm.load(os.path.join(fitted_folder, 'fitted.sarimax'))
        self.params = self.fitted.params
        self.fitted_vals = self.fitted.predict(exog=self.dm,
                                               start=self.dm.index.min(),
                                               end=self.dm.index.max())

    def _get_fcst_dm(self, horizon):
        logger.info('Building forecasting design matrix...')
        temp, precip, wind = self.data_adapter.get_temp_precip_wind(actuals=False, horizon=horizon)
        clean_spreads, dark_spreads = self.data_adapter.get_spreads(actuals=False, horizon=horizon)
        # forecasting design matrix:
        dm = pd.concat([dark_spreads, temp, precip, wind], axis=1)
        dm['const'] = 1.0
        dm = dm[self.COVARIATES]
        dm = dm.dropna(axis=0).sort_index(ascending=False).resample('D').mean()
        na_idx = stb.utils.dframe.df_see_null_na_values(dm, silent=True)
        assert len(na_idx) == 0
        # TODO: THIS NEEDS TO BE REMOVED
        dm = dm[-horizon:]
        assert dm.shape[0] == horizon
        return dm[-horizon:]

    def forecast(self, horizon):
        self.dm_forecast = self._get_fcst_dm(horizon=horizon)
        self.forecast_vals = self.fitted.predict(exog=self.dm_forecast,
                                                 start=self.dm_forecast.index.min(),
                                                 end=self.dm_forecast.index.max())
        self.forecast_vals.rename('predicted_ccgt', inplace=True)


if __name__ == '__main__':
    myModel = ShortTermPowerBurnModel(asof=date(2021, 2, 14),
                                      recalibrate=True)
    myModel.fit()
    myModel.forecast(horizon=14)
