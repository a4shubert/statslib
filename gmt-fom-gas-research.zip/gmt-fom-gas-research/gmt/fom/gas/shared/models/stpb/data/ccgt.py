import logging

import pandas as pd

logger = logging.getLogger(__file__)


def get_actuals_ccgt_from_file():
    def _get():
        path = r'\\trading1\Common\gasmodels\short_term_power_burn\data\UK\dependent_var\gas_view__power_station_gas_demand.csv'
        ccgt = pd.read_csv(path)
        ccgt.columns = ['date', 'value']
        ccgt['date'] = ccgt['date'].apply(lambda x: pd.to_datetime(x, format='%d/%m/%Y').date())
        ccgt['value'] = ccgt['value'].mul(-1.0)
        ccgt.set_index('date', inplace=True)
        ccgt.index.name = 'day'
        ccgt.columns = ['ccgt']
        ccgt.index = pd.DatetimeIndex(ccgt.index)
        return ccgt

    ccgt = _get()
    return ccgt.squeeze()
