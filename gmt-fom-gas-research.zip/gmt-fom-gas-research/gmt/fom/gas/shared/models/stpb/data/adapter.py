import math
from matplotlib import pyplot as plt
from matplotlib.font_manager import FontProperties

from gmt.fom.gas.shared.data_sources.mongo import GasMongo
import logging
logger = logging.getLogger(__file__)


class MongoAdapter:
    GAS_MODELS_DB = 'GasModels'
    STPB_POWER_VIEW_POWER_STATION_FUEL_TYPE_DEMAND = 'stpb_power_view_power_station_fuel_type_demand'
    STPB_GAS_VIEW_POWER_STATION_GAS_DEMAND = 'stpb_gas_view_power_station_gas_demand'

    STPB_POINT_CONNECT_HIST_FCST = 'stpb_point_connect_historical_forecast'

    STPB_COVARIATES_TEMPERATURE = 'stpb_covariates_temperature'
    STPB_COVARIATES_PRECIPITATION = 'stpb_covariates_precipitation'
    STPB_COVARIATES_WIND = 'stpb_covariates_wind'
    STPB_COVARIATES_DARK_SPREAD = 'stpb_covariates_dark_spread'
    STPB_COVARIATES_CLEAN_SPREAD = 'stpb_covariates_clean_spread'

    STPB_DESIGN_MATRIX = 'stpb_design_matrix'

    class Mapping:

        figsize = (9 * 1.6, 9)

        mask1 = 'date'
        mask2 = ['curve_id', 'effective_date', 'point_date']

    def __init__(self):
        self.mongo = GasMongo()
        self.mongo.choose_db(MongoAdapter.GAS_MODELS_DB)

    def load_stpb_gas_view_power_station_gas_demand(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_GAS_VIEW_POWER_STATION_GAS_DEMAND)
        data = self.mongo.select_all()
        return data

    def load_stpb_power_view_power_station_fuel_type_demand(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_POWER_VIEW_POWER_STATION_FUEL_TYPE_DEMAND)
        data = self.mongo.select_all()
        return data

    def load_stpb_historical_forecasts(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_POINT_CONNECT_HIST_FCST)
        data = self.mongo.select_all()
        data = data.set_index(MongoAdapter.Mapping.mask2).sort_index(level=0)
        return data

    def plot_historical_forecasts(self, df):
        curves = sorted(df.index.get_level_values(0).unique().tolist())
        mask = ['curve_id', 'effective_date', 'point_date']
        L = 3
        K = math.ceil(len(curves) / L)
        i = j = 0
        fig, axs = plt.subplots(K, L, figsize=(15, 15))
        df = df.reset_index()
        for curve in curves:
            DM = df.set_index(mask).sort_index(level=0).loc[curve]
            DM.mean(level=1).plot(ax=axs[i, j])
            axs[i, j].legend([curve])
            j += 1
            if j % L == 0:
                i += 1
                j = 0
        plt.suptitle('Forecasted curves:averaged across effective dates')
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()

    def load_design_matrix(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_DESIGN_MATRIX)
        data = self.mongo.select_all()
        data = data.set_index('day')
        return data

    def load_covariates_dark_spread(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_COVARIATES_DARK_SPREAD)
        data = self.mongo.select_all()
        data = data.set_index('point_date')
        return data

    def load_covariates_clean_spread(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_COVARIATES_CLEAN_SPREAD)
        data = self.mongo.select_all()
        data = data.set_index('point_date')
        return data

    def load_covariates_temperature(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_COVARIATES_TEMPERATURE)
        data = self.mongo.select_all()
        data = data.set_index('area_country_city_gas_day')
        return data

    def load_covariates_preciptation(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_COVARIATES_PRECIPITATION)
        data = self.mongo.select_all()
        data = data.set_index('area_country_city_gas_day')
        return data

    def load_covariates_wind(self):
        logger.info('Retrieving...')
        self.mongo.choose_collection(MongoAdapter.STPB_COVARIATES_WIND)
        data = self.mongo.select_all()
        data = data.set_index('area_country_city_gas_day')
        return data

    def plot_weather(self, df):
        fig, ax = plt.subplots(figsize=MongoAdapter.Mapping.figsize)
        df.dropna(axis=0).plot(ax=ax)

        fontP = FontProperties()
        fontP.set_size('12')
        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', prop=fontP)

        plt.show()


class DataAdapter(object):

    @classmethod
    def get_ccgt(cls, actuals=True):
        if actuals:
            from gmt.fom.gas.shared.models.stpb.data.ccgt import get_actuals_ccgt_from_file as get
            ccgt = get()
        else:
            raise ValueError('There is not forecasted values for ccgt')
        return ccgt

    @classmethod
    def get_temp_precip_wind(cls, actuals=True, horizon=None):
        if actuals:
            from gmt.fom.gas.shared.models.stpb.data.weather import get_actuals_temp_precip_wind_from_file as get
            temp, precip, wind = get()
        else:
            from gmt.fom.gas.shared.models.stpb.data.weather import get_forecast_temp_precip_wind as get
            temp, precip, wind = get(horizon=horizon)
        return temp, precip, wind

    @classmethod
    def get_spreads(cls, actuals=True, horizon=None):
        if actuals:
            from gmt.fom.gas.shared.models.stpb.data.spreads import get_actuals_clean_dark_spreads_from_file as get
            clean_spreads, dark_spreads = get()
        else:
            from gmt.fom.gas.shared.models.stpb.data.spreads import get_forecast_clean_dark_spreads as get
            clean_spreads, dark_spreads = get(horizon=horizon)
        return clean_spreads, dark_spreads