__import__('pkg_resources').declare_namespace(__name__)

from gmt.fom.gas.shared.statslib import utils
from gmt.fom.gas.shared.statslib._lib import explore
from gmt.fom.gas.shared.statslib._lib import metrics
from gmt.fom.gas.shared.statslib._lib import stat_plots
from gmt.fom.gas.shared.statslib._lib import stat_tests
from gmt.fom.gas.shared.statslib._lib import transforms
from gmt.fom.gas.shared.statslib._lib.cross_validation import CrossValidation
from gmt.fom.gas.shared.statslib._lib.datasets import datasets
from gmt.fom.gas.shared.statslib._lib.design_matrix import DesignMatrix, WindowGenerator
from gmt.fom.gas.shared.statslib._lib.gcalib import GeneralCalibrator
from gmt.fom.gas.shared.statslib._lib.gmodel import GeneralModel
from gmt.fom.gas.shared.statslib._smdt.smdt import SmartData
