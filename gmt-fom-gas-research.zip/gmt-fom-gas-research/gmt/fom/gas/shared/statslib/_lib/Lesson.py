class Model:
    def __init__(self, name='Linear model'):
        self.name = name
        self.X = None  # covariates
        self.y = None  # dependent variable
        self.dm = None  # design matrix
        self.dm_fcst = None  # forecast design matrix

        self.model = None  # model specification
        self.fitted = None  # fitted model

        print(f'{self.name} model has been instantiated')

    def _get_y(self):
        mask = ['date', 'Consumption']
        y = pd.read_csv('uschange.csv')[mask]
        y['date'] = pd.to_datetime(y['date'])
        y.set_index('date', inplace=True)
        self.y = y.squeeze()

    def _get_X(self):
        mask = ['date', 'Income', 'Production', 'Savings', 'Unemployment']
        X = pd.read_csv('uschange.csv')[mask]
        X['date'] = pd.to_datetime(X['date'])
        X.set_index('date', inplace=True)
        self.X = X

    def get_dm(self, intercept=True):
        self._get_y()
        self._get_X()
        if (self.y is not None) and (self.X is not None):
            self.dm = pd.concat([self.y, self.X], axis=1)
            if intercept:
                self.dm['const'] = 1.
        else:
            print('ERROR: in design matrix construction')

    def plot_dm(self, **kwargs):
        def get_standard_colors():
            return plt.rcParams['axes.prop_cycle'].by_key()['color']

        def plot_to_grid(df, columns=None, title='', plots_per_row=3, legend_on_a_side=False):
            if columns is None:
                columns = df.columns
            L = plots_per_row
            K = math.ceil(len(columns) / L)
            if K == 1:
                K += 1
            i = j = 0
            fig, axs = plt.subplots(K, L, figsize=(15, 15))
            my_colors = itertools.cycle(get_standard_colors())
            for curve in columns:
                df[curve].plot(ax=axs[i, j], color=next(my_colors))
                axs[i, j].legend([curve])
                j += 1
                if j % L == 0:
                    i += 1
                    j = 0
            plt.suptitle(title)
            if legend_on_a_side:
                plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.tight_layout()
            plt.show()

        flatten_lst = lambda my_lst: _functools.reduce(_operator.iconcat, my_lst, [])

        mask = filter(lambda c: c != 'const', self.dm.columns)
        plot_to_grid(self.dm[mask], plots_per_row=2, title='', **kwargs)

    def fit(self, **kwargs):
        self.model = sm.OLS(myModel.y, myModel.X, **kwargs)
        self.fitted = self.model.fit()

    def _get_diagnostics(self):
        def sumofsq(x, axis=0):
            """Helper function to calculate sum of squares along first axis"""
            return np.sum(x ** 2, axis=axis)

        self.v_hat = self.fitted.predict(exog=self.X)
        self.residuals = self.fitted.resid
        sigma2 = 1.0 / self.fitted.nobs * sumofsq(self.residuals)
        self.std_residuals = self.residuals / np.sqrt(sigma2)

        self.residuals = pd.Series(self.std_residuals, index=self.v_hat.index)
        self.std_residuals = pd.Series(self.std_residuals, index=self.v_hat.index)

    def plot_diagnostics(self, figsize=(8 * 1.6, 8)):
        def get_standard_colors():
            return plt.rcParams['axes.prop_cycle'].by_key()['color']

        self._get_diagnostics()

        fig, axs = plt.subplots(3, 2, figsize=figsize)
        clrs = get_standard_colors()
        self.std_residuals.plot(ax=axs[0, 0], color=clrs[1])
        axs[0, 0].hlines(0, self.v_hat.index.min(), self.v_hat.index.max())
        axs[0, 0].set_title('Standardized residuals')

        axs[0, 1].hist(self.std_residuals.values, density=True)
        from scipy.stats import gaussian_kde, norm
        kde = gaussian_kde(self.std_residuals)
        xlim = (-1.96 * 2, 1.96 * 2)
        x = np.linspace(xlim[0], xlim[1])
        axs[0, 1].plot(x, kde(x), label="KernelDensityEstimator")
        axs[0, 1].plot(x, norm.pdf(x), label="N(0,1)")
        axs[0, 1].set_xlim(xlim)
        axs[0, 1].legend()
        axs[0, 1].set_title("Histogram plus estimated density")

        sm.graphics.qqplot(self.std_residuals.values, line='q', fit=True, ax=axs[1, 0])
        axs[1, 0].set_title('Normal QQ Plot')

        sm.graphics.tsa.plot_acf(self.std_residuals, ax=axs[1, 1])
        axs[1, 1].set_title('Correlogram')

        axs[2, 0].scatter(self.fitted.fittedvalues, self.residuals.values)
        axs[2, 0].hlines(0, min(self.fitted.fittedvalues), max(self.fitted.fittedvalues))
        axs[2, 0].set_xlabel('calibrator')
        axs[2, 0].set_ylabel('resid')
        axs[2, 0].set_title('Fitted values vs. Residuals')

        axs[2, 1].scatter(range(len(self.std_residuals)), self.std_residuals.values)
        axs[2, 1].hlines(0, 0, len(self.std_residuals.values))
        axs[2, 1].set_xlabel('index')
        axs[2, 1].set_ylabel('std_resid')
        axs[2, 1].set_title('Index plot of standardized residuals')

        plt.tight_layout()
        plt.show()

    def forecast(self, exog):
        return myModel.fitted.predict(exog)