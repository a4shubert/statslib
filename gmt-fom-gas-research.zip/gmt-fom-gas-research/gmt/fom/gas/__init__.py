__import__('pkg_resources').declare_namespace(__name__)
from gmt.fom.gas.shared.config import config