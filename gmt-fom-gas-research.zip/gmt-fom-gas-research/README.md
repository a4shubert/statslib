# Repository 
 This repository contains the research and prototypes of gas desk analytical models

# Getting Started
1. Request and install Python Anaconda | PyCharm | Git Bash | Notepad ++
2. Using the file `environment.yml` create conda environment by running the command in the `cmd`:  
   `conda env create -f=environment.yml`
3. Clone this repository by running the command in Git Bash  
   `git clone https://tfs/tfs/Shared/FOM/_git/gmt-fom-gas-research`  
4.Checkout `develop` branch by running the command in Git Bash:    
   `git checkout develop`
5. Create personal folder in the `sandobx` folder
6. Start coding
7. Commit your changes to repo by running these commands in Git Bash:
    * `git pull origin develop`  
    * `git add .`
    * `git commit -m "short description of changes"  `
    * `git push origin develop`

# Tutorial
Have a look at `jupyter` folder. 
