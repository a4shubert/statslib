"""
This file will contain the jobs scheduler for the trial runs of the gas desk analytical models
"""

import logging
import time


from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from gmt.fom.gas.shared.jobs.net_back import job_net_back_model
from gmt.fom.gas.shared.jobs.git_storage import job_git_storage_pooled
from gmt.fom.gas.shared.jobs.stpb import job_stpb

logger = logging.getLogger(__file__)


if __name__ == '__main__':

    sched = BackgroundScheduler()
    cron_net_back = CronTrigger(day_of_week='tue-sat', hour='3', minute='0')
    sched.add_job(job_net_back_model, cron_net_back, misfire_grace_time=60)

    cron_git_storage = CronTrigger(day_of_week='tue-sat', hour='4', minute='0')
    sched.add_job(job_git_storage_pooled, cron_git_storage, misfire_grace_time=60)

    cron_stpb = CronTrigger(day_of_week='tue-sat', hour='5', minute='0')
    sched.add_job(job_stpb, cron_stpb, misfire_grace_time=60)

    sched.start()
    while True:
        time.sleep(2)
