stopwatches.ForwardSimulation.Stop();
_logger?.LogInformation("Starting calculations of optimal decisions by simulation forward in time.");

double forwardNpv = pvBySim.Average();
_logger?.LogInformation("Forward Pv: " + forwardNpv.ToString("N", CultureInfo.InvariantCulture));

// Calculate NPVs for first active period using current inventory
// TODO this is unnecessarily introducing floating point error if the val date is during the storage active period and there should not be a Vector of simulated spot prices
double backwardNpv = storageActualValuesNextPeriod[0].Average();

_logger?.LogInformation("Backward Pv: " + backwardNpv.ToString("N", CultureInfo.InvariantCulture));

double expectedFinalInventory = Average(inventoryBySim[inventoryBySim.NumRows - 1]);
// Profile at storage end when no decisions can happen
storageProfiles[storageProfiles.Length - 1] = new StorageProfile(expectedFinalInventory, 0.0, 0.0, 0.0, 0.0, endPeriodPv);

var deltasSeries = new DoubleTimeSeries<T>(periodsForResultsTimeSeries[0], deltas);
var storageProfileSeries = new TimeSeries<T, StorageProfile>(periodsForResultsTimeSeries[0], storageProfiles);
var triggerPriceVolumeProfiles = new TimeSeries<T, TriggerPriceVolumeProfiles>(periodsForResultsTimeSeries.First(), triggerVolumeProfilesArray);
var triggerPrices = new TimeSeries<T, TriggerPrices>(periodsForResultsTimeSeries.First(), triggerPricesArray);

var regressionSpotPricePanel = Panel.UseRawDataArray(regressionSpotSims.SpotPrices, regressionSpotSims.SimulatedPeriods, numSims);
var valuationSpotPricePanel = Panel.UseRawDataArray(valuationSpotSims.SpotPrices, valuationSpotSims.SimulatedPeriods, numSims);
lsmcParams.OnProgressUpdate?.Invoke(1.0); // Progress with approximately 1.0 should have occurred already, but might have been a bit off because of floating-point error.

stopwatches.All.Stop();
if (_logger != null)
{
	string profilingReport = stopwatches.GenerateProfileReport();
	_logger.LogInformation("Profiling Report:");
	_logger.LogInformation(Environment.NewLine + profilingReport);
}

return new LsmcStorageValuationResults<T>(forwardNpv, deltasSeries, storageProfileSeries, regressionSpotPricePanel,
	valuationSpotPricePanel, inventoryBySim, injectWithdrawVolumeBySim, cmdtyConsumedBySim, inventoryLossBySim, netVolumeBySim, 
	triggerPrices, triggerPriceVolumeProfiles, pvByPeriodAndSim, pvBySim);