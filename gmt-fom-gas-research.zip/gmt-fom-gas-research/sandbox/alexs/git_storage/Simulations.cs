_logger?.LogInformation("Starting valuation spot price simulation.");
stopwatches.ValuationPriceSimulation.Start();
ISpotSimResults<T> valuationSpotSims = lsmcParams.ValuationSpotSimsGenerator();
stopwatches.ValuationPriceSimulation.Stop();
_logger?.LogInformation("Valuation spot price simulation complete.");