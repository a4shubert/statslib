_logger?.LogInformation("Starting backward induction.");
stopwatches.BackwardInduction.Start();
foreach (T period in periodsForResultsTimeSeries.Reverse().Skip(1))
{
	double[] nextPeriodInventorySpaceGrid = inventorySpaceGrids[backCounter + 1];
	Vector<double>[] storageRegressValuesNextPeriod = new Vector<double>[nextPeriodInventorySpaceGrid.Length];

	if (period.Equals(lsmcParams.CurrentPeriod))
	{
		currentPeriodContinuationValues = new double[nextPeriodInventorySpaceGrid.Length];
		// Current period, for which the price isn't random so expected storage values are just the average of the values for all sims
		for (int i = 0; i < nextPeriodInventorySpaceGrid.Length; i++)
		{
			Vector<double> storageValuesBySimNextPeriod = storageActualValuesNextPeriod[i];
			double expectedStorageValueNextPeriod = storageValuesBySimNextPeriod.Average();
			storageRegressValuesNextPeriod[i] = Vector<double>.Build.Dense(numSims, expectedStorageValueNextPeriod); // TODO this is a bit inefficent, review
			currentPeriodContinuationValues[i] = expectedStorageValueNextPeriod;
		}
	}
	else
	{
		PopulateDesignMatrix(designMatrix, period, regressionSpotSims, basisFunctionList);
		stopwatches.PseudoInverse.Start();
		QR<double> designMatrixQr = designMatrix.QR(QRMethod.Thin);
		Matrix<double> rInverse = designMatrixQr.R.Inverse();
		designMatrixQr.Q.Transpose(qTranspose);
		rInverse.Multiply(qTranspose, pseudoInverse);
		stopwatches.PseudoInverse.Stop();

		var thisPeriodRegressCoeffs = new Panel<int, double>(Enumerable.Range(0, nextPeriodInventorySpaceGrid.Length), basisFunctionList.Count);
		// TODO doing the regressions for all next inventory could be inefficient as they might not all be needed
		for (int i = 0; i < nextPeriodInventorySpaceGrid.Length; i++)
		{
			Vector<double> storageValuesBySimNextPeriod = storageActualValuesNextPeriod[i];
			Vector<double> regressResults = pseudoInverse.Multiply(storageValuesBySimNextPeriod);
			Vector<double> estimatedContinuationValues = designMatrix.Multiply(regressResults);
			storageRegressValuesNextPeriod[i] = estimatedContinuationValues;
			// Save regression coeffs for later use
			Span<double> regressCoeffsSpan = thisPeriodRegressCoeffs[i];
			for (int j = 0; j < regressCoeffsSpan.Length; j++)
				regressCoeffsSpan[j] = regressResults[j];
		}
		regressCoeffsBuilder.Add(period, thisPeriodRegressCoeffs); // Key for regressCoeffs is period of simulated prices/factors, 
		//i.e. the regressor, which is the period before the period of continuation value being approximated
	}
	
	double[] inventorySpaceGrid;
	if (period.Equals(startActiveStorage))
		inventorySpaceGrid = new[] { lsmcParams.Inventory };
	else
	{
		(double inventorySpaceMin, double inventorySpaceMax) = inventorySpace[period];
		inventorySpaceGrid = lsmcParams.GridCalc.GetGridPoints(inventorySpaceMin, inventorySpaceMax)
									.ToArray();
	}
	(double nextStepInventorySpaceMin, double nextStepInventorySpaceMax) = inventorySpace[period.Offset(1)];

	var storageActualValuesThisPeriod = new Vector<double>[inventorySpaceGrid.Length]; // TODO change type to DenseVector?

	Day cmdtySettlementDate = lsmcParams.SettleDateRule(period);
	double discountFactorFromCmdtySettlement = DiscountToCurrentDay(cmdtySettlementDate);

	ReadOnlySpan<double> simulatedPrices;
	if (period.Equals(lsmcParams.CurrentPeriod))
	{
		double spotPrice = lsmcParams.ForwardCurve[period];
		simulatedPrices = Enumerable.Repeat(spotPrice, numSims).ToArray(); // TODO inefficient - review.
	}                
	else
		simulatedPrices = regressionSpotSims.SpotPricesForPeriod(period).Span;

	for (int inventoryIndex = 0; inventoryIndex < inventorySpaceGrid.Length; inventoryIndex++)
	{
		double inventory = inventorySpaceGrid[inventoryIndex];
		InjectWithdrawRange injectWithdrawRange = lsmcParams.Storage.GetInjectWithdrawRange(period, inventory);
		double inventoryLoss = lsmcParams.Storage.CmdtyInventoryPercentLoss(period) * inventory;
		double[] decisionSet = StorageHelper.CalculateBangBangDecisionSet(injectWithdrawRange, inventory, inventoryLoss,
			nextStepInventorySpaceMin, nextStepInventorySpaceMax, lsmcParams.NumericalTolerance, lsmcParams.ExtraDecisions);
		IReadOnlyList<DomesticCashFlow> inventoryCostCashFlows = lsmcParams.Storage.CmdtyInventoryCost(period, inventory);
		double inventoryCostNpv = inventoryCostCashFlows.Sum(cashFlow => cashFlow.Amount * DiscountToCurrentDay(cashFlow.Date));

		double[] injectWithdrawCostNpvs = new double[decisionSet.Length];
		double[] cmdtyUsedForInjectWithdrawVolume = new double[decisionSet.Length];
		
		var regressionContinuationValueByDecisionSet = new Vector<double>[decisionSet.Length];
		var actualContinuationValueByDecisionSet = new Vector<double>[decisionSet.Length];
		for (int decisionIndex = 0; decisionIndex < decisionSet.Length; decisionIndex++)
		{
			double decisionVolume = decisionSet[decisionIndex];

			// Inject/Withdraw cost (same for all price sims)
			injectWithdrawCostNpvs[decisionIndex] = InjectWithdrawCostNpv(lsmcParams.Storage, decisionVolume, period, inventory, DiscountToCurrentDay);

			// Cmdty Used For Inject/Withdraw (same for all price sims)
			cmdtyUsedForInjectWithdrawVolume[decisionIndex] = CmdtyVolumeConsumedOnDecision(lsmcParams.Storage, decisionVolume, period, inventory);

			// Calculate continuation values
			double inventoryAfterDecision = inventory + decisionVolume - inventoryLoss;
			for (int inventoryGridIndex = 0; inventoryGridIndex < nextPeriodInventorySpaceGrid.Length; inventoryGridIndex++) // TODO use binary search?
			{
				double nextPeriodInventory = nextPeriodInventorySpaceGrid[inventoryGridIndex];
				if (Math.Abs(nextPeriodInventory - inventoryAfterDecision) < 1E-8) // TODO get rid of hard coded constant
				{
					regressionContinuationValueByDecisionSet[decisionIndex] = storageRegressValuesNextPeriod[inventoryGridIndex];
					actualContinuationValueByDecisionSet[decisionIndex] = storageActualValuesNextPeriod[inventoryGridIndex];
					break;
				}
				if (nextPeriodInventory > inventoryAfterDecision)
				{
					// Linearly interpolate inventory space
					double lowerInventory = nextPeriodInventorySpaceGrid[inventoryGridIndex - 1];
					double upperInventory = nextPeriodInventory;
					double inventoryGridSpace = upperInventory - lowerInventory;
					double lowerWeight = (upperInventory - inventoryAfterDecision) / inventoryGridSpace;
					double upperWeight = 1.0 - lowerWeight;
					
					// Regression storage values
					Vector<double> lowerRegressStorageValues = storageRegressValuesNextPeriod[inventoryGridIndex - 1];
					Vector<double> upperRegressStorageValues = storageRegressValuesNextPeriod[inventoryGridIndex];

					var interpolatedRegressContinuationValue = 
						WeightedAverage<T>(lowerRegressStorageValues, 
							lowerWeight, upperRegressStorageValues, upperWeight, numSimsMemoryBuffer);

					regressionContinuationValueByDecisionSet[decisionIndex] = interpolatedRegressContinuationValue;

					// Actual (simulated) storage values
					Vector<double> lowerActualStorageValues = storageActualValuesNextPeriod[inventoryGridIndex - 1];
					Vector<double> upperActualStorageValues = storageActualValuesNextPeriod[inventoryGridIndex];

					Vector<double> interpolatedActualContinuationValue =
							WeightedAverage<T>(lowerActualStorageValues, lowerWeight, 
								upperActualStorageValues, upperWeight, numSimsMemoryBuffer);
					actualContinuationValueByDecisionSet[decisionIndex] = interpolatedActualContinuationValue;
					break;
				}
			}
		}

		var storageValuesBySim = new DenseVector(numSims);
		var decisionNpvsRegress = new double[decisionSet.Length];
		for (int simIndex = 0; simIndex < numSims; simIndex++)
		{
			double simulatedSpotPrice = simulatedPrices[simIndex];
			for (var decisionIndex = 0; decisionIndex < decisionSet.Length; decisionIndex++)
			{
				double decisionVolume = decisionSet[decisionIndex];

				double injectWithdrawNpv = -decisionVolume * simulatedSpotPrice * discountFactorFromCmdtySettlement;
				double cmdtyUsedForInjectWithdrawNpv = -cmdtyUsedForInjectWithdrawVolume[decisionIndex] * simulatedSpotPrice * 
													   discountFactorFromCmdtySettlement;
				double immediateNpv = injectWithdrawNpv - injectWithdrawCostNpvs[decisionIndex] + cmdtyUsedForInjectWithdrawNpv;

				double continuationValue = regressionContinuationValueByDecisionSet[decisionIndex][simIndex]; // TODO potentially this array lookup could be quite costly

				double totalNpv = immediateNpv + continuationValue - inventoryCostNpv; // TODO IMPORTANT check if inventoryCostNpv should be subtracted;
				decisionNpvsRegress[decisionIndex] = totalNpv;
			}
			(double optimalRegressDecisionNpv, int indexOfOptimalDecision) = StorageHelper.MaxValueAndIndex(p);
			
			// TODO do this tidier an potentially more efficiently
			double adjustFromRegressToActualContinuation =  
									- regressionContinuationValueByDecisionSet[indexOfOptimalDecision][simIndex]
									+ actualContinuationValueByDecisionSet[indexOfOptimalDecision][simIndex];
			double optimalActualDecisionNpv = optimalRegressDecisionNpv + adjustFromRegressToActualContinuation;

			storageValuesBySim[simIndex] = optimalActualDecisionNpv;
		}
		storageActualValuesThisPeriod[inventoryIndex] = storageValuesBySim;
	}
	inventorySpaceGrids[backCounter] = inventorySpaceGrid;
	storageActualValuesNextPeriod = storageActualValuesThisPeriod;
	backCounter--;
	progress += backStepProgressPcnt;
	lsmcParams.OnProgressUpdate?.Invoke(progress);
	lsmcParams.CancellationToken.ThrowIfCancellationRequested();
}
stopwatches.BackwardInduction.Stop();
_logger?.LogInformation("Completed backward induction.");