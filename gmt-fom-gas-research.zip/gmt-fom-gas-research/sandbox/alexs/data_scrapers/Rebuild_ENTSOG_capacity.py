import pandas as pd
import datetime
import numpy as np

#----------------Dates used in API URL ----------------------------------------------------------------------
today = datetime.date.today()
yesterday = today - datetime.timedelta(days = 1)
tomorrow = today + datetime.timedelta(days = 665)
#------------------------------------------------------------------------------------------------------------

#----------------Further variables to change for API request ------------------------------------------------
fromDate = yesterday.strftime('%Y-%m-%d')
toDate = tomorrow.strftime('%Y-%m-%d')
#toDate = datetime.datetime.today().strftime('%Y-%m-%d')
#------------------------------------------------------------------------------------------------------------

#============================================================
#THIS QUERIES ENTSOG AND RETURNS REONOMINATIONS FOR ALL OPERATORS

url = (
       "https://transparency.entsog.eu/api/v1/operationalData.csv?&"+
       "delimiter=comma&" +
       "indicator=" +
       "Firm%20Technical," +
       "Firm%20Booked," +
       "Firm%20Available," +
       "Interruptible%20Total," +
       "Interruptible%20Booked" +
       "Interruptible%20Available" +
       "&periodType=day&timezone=CET&limit=-1&dataset=1" 
       +"&from="+ 
       fromDate +
       "&to="+ 
       toDate
       )


df = pd.read_csv(url)

columns = ['id', 'indicator', 'periodType', 'periodFrom', 'periodTo',
       'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey', 'pointLabel',
       'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
       'value']
df = df[columns]
#These need to be added ['fromCountry', 'fromCountryCode', 'toCountry', 'fromSystem', 'toCountryCode', 'toSystem']

#----Converts the columns into datetime & set the index
df[['periodFrom','periodTo','lastUpdateDateTime']] = df[['periodFrom','periodTo','lastUpdateDateTime']].apply(pd.to_datetime)
#df[['value']]= df[['value']] * 9.09e-8
df[['unit']]= 'GWh/d'
df[['value']]= df[['value']] * 1.0e-7

df.reset_index(drop=True, inplace=True)
df = df.sort_values(['tsoItemIdentifier','directionKey']).copy()

#====================================
#Creates a list of all the operator keys from the Full Data so that we search for the to and from countries below
TotalOperatorKeys = df['operatorKey'].unique()
TotalOperatorKeys = TotalOperatorKeys.tolist()

#==================================
#Looks up all the Countries each connection if flow from.
CountryconnectionID = pd.DataFrame()

for url in TotalOperatorKeys:
    try:
        url = "https://transparency.entsog.eu/api/v1/Interconnections.csv?&fromOperatorKey=" + url
        df1=pd.read_csv(url)
        print(url)
        CountryconnectionID = CountryconnectionID.append(df1)
    except:
        pass

Columns = ['fromSystemLabel', 'fromCountryKey', 'fromCountryLabel',
       'fromOperatorKey',  'fromTsoItemIdentifier',
       'toSystemLabel', 'toCountryKey', 'toCountryLabel']

CountryconnectionID = CountryconnectionID[Columns]

CountryconnectionID.rename(columns={'fromTsoItemIdentifier':'tsoItemIdentifier',
                                    'fromOperatorKey':'operatorKey'}, inplace=True)
#=====================================

FromCountryData = pd.merge(df, CountryconnectionID, on=['operatorKey','tsoItemIdentifier'], how='outer')
ToCountryData = FromCountryData[FromCountryData['fromCountryLabel'].isnull()]

FromCountryData = FromCountryData.dropna()
ToCountryData = ToCountryData[ToCountryData['tsoEicCode'].notna()]

FromCountryData.rename(columns={'fromCountryKey':'toCountryCode',
                      'fromSystemLabel':'toSystem',
                      'fromCountryLabel':'toCountry',
                      'toCountryLabel':'fromCountry',
                      'toSystemLabel':'fromSystem',
                      'toCountryKey':'fromCountryCode'}, inplace=True)
#==========================================

columns = ['id', 'indicator', 'periodType', 'periodFrom', 'periodTo',
       'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey', 'pointLabel',
       'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
       'value']

ToCountryData = ToCountryData[columns]

#==========================================
#Looks up all the connections that countries are flowing to

Other_CountryconnectionID = pd.DataFrame()

for url in TotalOperatorKeys:
    try:
        url = "https://transparency.entsog.eu/api/v1/Interconnections.csv?&toOperatorKey=" + url
        df1=pd.read_csv(url)
        print(url)
        Other_CountryconnectionID = Other_CountryconnectionID.append(df1)
    except:
        pass
    
columns = ['fromSystemLabel', 'fromCountryKey', 'fromCountryLabel',
       'toSystemLabel', 'toCountryKey', 'toCountryLabel', 'toOperatorKey',
       'toTsoItemIdentifier']

Other_CountryconnectionID = Other_CountryconnectionID[columns]

#Renames the columns so that the different dataframes can me joined together  
Other_CountryconnectionID.rename(columns={'toTsoItemIdentifier':'tsoItemIdentifier',
                                          'toOperatorKey':'operatorKey'}, inplace=True)

#==========================================
#Joins the dataframes on the columns tsoItemIdentifer and operatorKey
OtherCountryData = pd.merge(ToCountryData, Other_CountryconnectionID, on=['operatorKey','tsoItemIdentifier'], how='outer')
#Keeps only the rows with data in the tsoEicCode column
OtherCountryData = OtherCountryData[OtherCountryData['tsoEicCode'].notna()]
OtherCountryData = OtherCountryData[OtherCountryData['pointLabel'].notna()]
OtherCountryData = OtherCountryData.dropna()

OtherCountryData.rename(columns={'fromSystemLabel':'fromSystem',
                                 'fromCountryKey':'fromCountryCode',
                                 'fromCountryLabel':'fromCountry',
                                 'toSystemLabel':'toSystem',
                                 'toCountryKey':'toCountryCode',
                                 'toCountryLabel':'toCountry'}, inplace=True)
#========================================================

#Combines the two complete dataframes together
Final = OtherCountryData.append([FromCountryData])
#Removes the foregin letters
Final['pointLabel'] = Final['pointLabel'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode('utf-8')
Final['operatorLabel'] = Final['operatorLabel'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode('utf-8')
Final['fromSystem'] = Final['fromSystem'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode('utf-8')
Final['toSystem'] = Final['toSystem'].str.normalize('NFKD').str.encode('ascii', errors='ignore').str.decode('utf-8')

Final['value'] = pd.to_numeric(Final['value'])


Final2 = Final.copy()
#=======================================================
#===========================================================
Final2.set_index('pointLabel', inplace=True)
Final2['row'] = range(len(Final2))
print(Final2)

starts = Final2[['periodFrom', 'value', 'indicator', 'id', 'periodType',
       'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey',
       'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
       'fromSystem',
       'fromCountryCode', 'fromCountry', 'toSystem', 'toCountryCode',
       'toCountry' ,'row']].rename(columns={'periodFrom': 'Date'})

ends = Final2[['periodTo', 'value', 'indicator','id', 'periodType',
       'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey',
       'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
       'fromSystem',
       'fromCountryCode', 'fromCountry', 'toSystem', 'toCountryCode',
       'toCountry','row']].rename(columns={'periodTo':'Date'})

#================================================================
df_decomp = pd.concat([starts, ends]).drop_duplicates()
df_decomp = df_decomp.set_index('row', append=True)
df_decomp.sort_index()
print(df_decomp)
df_decomp = df_decomp.groupby(level=[0,1]).apply(lambda x: x.set_index('Date').resample('D').fillna(method='pad'))
df_decomp = df_decomp.reset_index(level=1, drop=True)
df_decomp = df_decomp.reset_index()
df_decomp = df_decomp.drop_duplicates()
df_decomp = df_decomp.dropna()
df_decomp = df_decomp.rename(columns={'Date':'periodFrom'})

from datetime import timedelta
df_decomp["periodTo"] =  df_decomp["periodFrom"] + timedelta(days=1)
#===================================================================

#===================================================================

#Grouped = (df_decomp.set_index('periodFrom')
   #.groupby(['pointLabel', 'value', 'indicator', 'id', 'periodType',
       #'operatorKey', 'tsoEicCode', 'operatorLabel', 'pointKey',
       #'tsoItemIdentifier', 'directionKey', 'unit', 'lastUpdateDateTime',
       #'fromSystem', 'fromCountryCode', 'fromCountry', 'toSystem',
       #'toCountryCode', 'toCountry', 'periodTo'])
  # .resample(rule='M', closed='left', label='left', base=0, level=0)
   #.mean()
   #.reset_index())
#===================================================================

#----------------This allows the returned data to be put into the database ------------------------------------------------
# This website shows you how to use the library sqlachemy: https://docs.sqlalchemy.org/en/latest/core/engines.html
from sqlalchemy import create_engine
#engine = create_engine('postgresql://chris:monopoly@192.168.0.32:5432/natgas',echo=False)
engine = create_engine('postgresql://postgres:Dma1nman@localhost/natgas',echo=False)
df_decomp.to_sql(name='ENTSOGcapacity', con=engine, if_exists = 'replace', 
                 index=False, chunksize=100000,method=None)
#Total_Data.to_sql(name='dailyallocationstest', con=engine, if_exists = 'replace', index=False)
#The line below is used to query from the database.
#data = pd.read_sql('SELECT * FROM public.dailyallocations', engine)
#data = pd.read_sql("""SELECT * FROM public.dailyallocations WHERE "periodFrom" > NOW() - INTERVAL '32 day'""", engine)
#------------------------------------------------------------------------------------------------------------

