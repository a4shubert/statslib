"""
-Run:  python net_back_model_test.py -v
"""
import os
import unittest
from datetime import datetime, date

import numpy as np
import pandas as pd

from gmt.fom.gas.shared.models.net_back.model import NetBackModel, NetBackSymbols


class NetBackModelTest(unittest.TestCase):
    def setUp(self) -> None:
        self.core_path = os.path.dirname(__file__)
        self.data_path = os.path.join(self.core_path, 'data')

    @staticmethod
    def conv_dates_df(df):
        cols = [
            NetBackSymbols.SYM_POINTDATE_ORIGIN,
            NetBackSymbols.SYM_EFFECTIVEDATE,
            NetBackSymbols.SYM_POINTDATE_DESTINATION
        ]
        for col in cols:
            df[col] = df[col].apply(
                lambda t: pd.to_datetime(datetime.strptime(t, '%Y-%m-%d')))
        return df

    def test_assert_net_back_equal(self):
        benchmark = pd.read_csv(os.path.join(self.data_path, '2018_01_02'))
        benchmark = self.conv_dates_df(benchmark)
        start_date = date(2018, 1, 2)
        end_date = start_date
        nb_model = NetBackModel(start_date, end_date)
        nb_model.fit()
        netback = nb_model.one_tick_forecast(end_date, True)
        float_cols = [c for c in netback if netback[c].dtype == "float32"]
        netback[float_cols] = netback[float_cols].astype(np.float64)
        netback.to_csv(r'C:\git\benchmark.csv', index=False)
        pd.testing.assert_frame_equal(benchmark, netback[benchmark.columns])


if __name__ == '__main__':
    unittest.main()
